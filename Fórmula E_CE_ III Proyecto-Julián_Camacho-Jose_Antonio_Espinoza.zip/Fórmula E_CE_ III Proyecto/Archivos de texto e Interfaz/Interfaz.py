"""
Instituto Tecnológico de Costa Rica
    Ingeniería en Computadores
      Taller de Programación


    III Proyecto Programado
          Fórmula E_Tec
          Segunda Parte


            Profesor:
       Jeff Schmidt Peralta

          Estudiantes:
   José Julián Camacho Hernández
   José Antonio Espinoza Chaves

           I semestre
              2019

"""


### ========== BIBLIOTECAS Y FUNCIONES GENERALES ========== ###

from tkinter import *
from io import open
import time
import os
from WiFiClient import NodeMCU

carro = NodeMCU()
carro.start()

# Función para cargar imágenes
def cargarimagen(nombre): 
    ruta= os.path.join('Images_FE',nombre)
    imagen= PhotoImage(file=ruta)
    return imagen

# E: el nombre de un archivo, la línea que se desea leer
# S: lectura de la línea seleccionada
# R: ---
def Read(archivo, linea):
    archivo = open (archivo, "r")
    lineas_texto = archivo.readlines()
    archivo.close()
    texto = lineas_texto[linea]
    return str(texto)

"""
E: dos matrices, una posición
S: los datos que coincidan en las dos listas
R: ---
"""
def ordenamiento(mat, mat2, elem):
    result = []
    for i in range(len(mat)):
        for j in range(len(mat2)):
            if mat[i] == mat2[j][elem]:
                result.append(mat2[j][0])
    return result

"""
E: una lista
S: la lista invertida
R: ---
"""
def invertir(lista):
    inv = []
    i = 1
    while i <= len(lista):
        inv.append(lista[len(lista)-i])
        i += 1
    return inv

"""
E: una matriz, una posición
S: obtiene los datos en la posición de entrada, ordenados
R: ---
"""
def get_RPX(mat, elem):
    RPG_list = []
    for i in range(len(mat)):
        RPG_list.append(mat[i][elem])
    return sorted(RPG_list)

# Fución para calcular el índice ganador de la escudería
def Indice_Ganador_Escuderia(mat):
    vic = 0
    comp = 1
    n = len(mat)
    for i in range (n):
        vic += mat[i][1]
        comp += mat[i][0]
    return round((vic/comp*100), 2)

# Funciones para transformar un número en string del archivo de texto, a un entero
def to_Int(elem):
    delim = "\n"
    punto = "."
    result = []
    for i in range(len(elem)):
        if elem[i] == delim or elem[i] == punto:
            break
        else:
            result.append(int(elem[i]))
    return integer(result)

def integer(lista):
    resultado = 0
    j = 1
    for i in range(len(lista)):
        if isinstance(lista[i], int):
            resultado += lista[i] * 10 ** (len(lista)-j)
        else:
            break
        j += 1
    return resultado

# Función para obtener un string hasta un delimitador
def to_String(elem):
    result = ""
    for i in range(len(elem)):
        if elem[i] != "\n":
            result += str(elem[i])
        else:
            break
    return result

# Funciones para calcular RGP, REP, e Índice Ganador
def calcular_RGP(vic, pod, total, aban):
    RGP = ((vic + pod)/(total-aban))*100
    return round(RGP, 2)

def calcular_REP(vic, total, aban):
    REP = ((vic)/(total-aban))*100
    return round(REP, 2)


### ========== VENTANA INICIO ========== ###

def Ventana_inicio():
    global Ventana_Inicio, Canvas_Inicio
    # Definir la ventana, su canvas y el tamaño respectivo
    Ventana_Inicio = Tk()
    Ventana_Inicio.title("Inicio")
    Ventana_Inicio.minsize(850, 550)
    Ventana_Inicio.resizable(width = NO, height = NO)
    Canvas_Inicio = Canvas(Ventana_Inicio, width = 850, height = 550, bg = "black")
    Canvas_Inicio.place(x = 0, y = 0)
    
    Imag_Fondo_Inicio = cargarimagen("BMW BG-min.png") 
    Fondo_Inicio = Canvas_Inicio.create_image(0,0, image = Imag_Fondo_Inicio, anchor = NW)
    Imagen_Logo_Inicio = cargarimagen(Read("archivo_bmw.txt", 4)) 
    ImagL_Inicio = Canvas_Inicio.create_image(340,430, image = Imagen_Logo_Inicio, anchor = NW)
    
    Li_1 = Label(Ventana_Inicio, text = Read("archivo_bmw.txt", 0), bg = "black", fg = "White", font = ("Consolas","20"), anchor = NW)
    Li_1.place(x = 30, y = 60)
    Li_2 = Label(Ventana_Inicio, text = Read("archivo_bmw.txt", 1), bg = "black", fg = "White", font = ("Consolas","15"), anchor = NW)
    Li_2.place(x = 30, y = 100)
    Canvas_Inicio.create_text(700, 30, text="Índice\nGanador %", fill = "White", font = ("Consolas","18"),anchor =NW)
    Li_3 = Label(Ventana_Inicio, text = Indice_Ganador_Escuderia(IND), bg = "black", fg = "White", font = ("Consolas","15"), anchor = NW).place(x = 730, y = 90)

    Canvas_Inicio.create_text(500, 30, text="Temporada", fill = "White", font = ("Consolas","16"),anchor =NW)
    Li_4 = Label(Ventana_Inicio, text = 2019, bg = "black", fg = "White", font = ("Consolas","15"), anchor = NW).place(x = 530, y = 60)

    Canvas_Inicio.create_text(340, 410, text="Patrocinador", fill = "White", font = ("Consolas","10"),anchor =NW)
    Canvas_Inicio.create_text(560, 410, text="Logo", fill = "White", font = ("Consolas","11"),anchor =NW)

    # Creación de texto desde archivos de texto
    Canvas_Inicio.create_text(510, 140, text="Nuestros Pilotos:", fill = "Black", font = ("Consolas","16"),anchor =NW)
    Canvas_Inicio.create_text(530, 160, text=Read("Félix Da Costa.txt", 0), fill = "White", font = ("Consolas","16"),anchor =NW)
    Canvas_Inicio.create_text(510, 160, text=Read("Félix Da Costa.txt", 8), fill = "White", font = ("Consolas","16"),anchor =NW)
    Canvas_Inicio.create_text(530, 190, text=Read("Alexander Sims.txt", 0), fill = "White", font = ("Consolas","16"),anchor =NW)
    Canvas_Inicio.create_text(510, 190, text=Read("Alexander Sims.txt", 8), fill = "White", font = ("Consolas","16"),anchor =NW)

    Canvas_Inicio.create_text(510, 300, text="Nuestros Automóviles:", fill = "Black", font = ("Consolas","16"),anchor =NW)
    Canvas_Inicio.create_text(610, 330, text=Read("A-BMW.txt", 0), fill = "White", font = ("Consolas","16"),anchor =NW)  
    Canvas_Inicio.create_text(540, 330, text=Read("A-BMW.txt", 3), fill = "White", font = ("Consolas","16"),anchor =NW)  
    Canvas_Inicio.create_text(680, 330, text=Read("A-BMW.txt", 1), fill = "White", font = ("Consolas","16"),anchor =NW)  
    Canvas_Inicio.create_text(510, 330, text="1", fill = "White", font = ("Consolas","16"),anchor =NW)  

    # Botones para cambiar de ventana
    About_Button = Button(Canvas_Inicio,text ="About" , bg = "black", fg = "White", command = Ventana_about)
    About_Button.place(x = 30, y = 500)
    Tabla_Button = Button(Canvas_Inicio,text ="Tabla de \n Posiciones" , bg = "black", fg = "White", command = Ventana_tabla)
    Tabla_Button.place(x = 100, y = 495)
    Escuderias_Button = Button(Canvas_Inicio,text ="Lista de \n escuderías" , bg = "black", fg = "White", command = Ventana_escuderias)
    Escuderias_Button.place(x = 200, y = 495)
    Crear_Piloto_Button = Button(Canvas_Inicio,text ="Agregar nuevo \n piloto" , bg = "black", fg = "dark turquoise", command = Ventana_crear_pilotos)
    Crear_Piloto_Button.place(x = 650, y = 495)
    Crear_Auto_Button = Button(Canvas_Inicio,text ="Nueva \n temporada" , bg = "black", fg = "dark turquoise", command = Ventana_crear_autos)
    Crear_Auto_Button.place(x = 750, y = 495)
    Cambiar_Button = Button(Canvas_Inicio,text ="Cambiar" , bg = "black", fg = "dark turquoise", command = Ventana_cambiar)
    Cambiar_Button.place(x = 450, y = 400)
    Ventana_Inicio.mainloop()

# Lista para el índice ganador de la escudería    
IND = [[(to_Int(Read("Félix Da Costa.txt", 4))), (to_Int(Read("Félix Da Costa.txt", 6)))], [(to_Int(Read("Alexander Sims.txt", 4))), (to_Int(Read("Alexander Sims.txt", 6)))]]     


### ========== VENTANA ABOUT ========== ###

def Ventana_about():
    # Definir la ventana, su canvas y el tamaño respectivo
    Ventana_Inicio.withdraw()
    Ventana_About = Toplevel()
    Ventana_About.title("About")
    Ventana_About.minsize(850, 550)
    Ventana_About.resizable(width = NO, height = NO)
    Canvas_About = Canvas(Ventana_About, width = 850, height = 550, bg = "black")
    Canvas_About.place(x = 0, y = 0)
    Imagen1_About = cargarimagen("Formula_E_Logo.png") 
    Imag1_About = Canvas_About.create_image(650, 20, image = Imagen1_About, anchor = NW)
    Imagen2_About = cargarimagen(Read("archivo_about.txt", 12)) 
    Imag2_About = Canvas_About.create_image(50, 300, image = Imagen2_About, anchor = NW)

    Imagen3_About = cargarimagen("Jose2.png") 
    Imag3_About = Canvas_About.create_image(550, 300, image = Imagen3_About, anchor = NW)

    # Creación de texto desde archivos de texto
    La_1 = Label(Ventana_About, text = Read("archivo_about.txt", 0), font = ("Consolas","18"), bg = "black", fg = "dark turquoise", anchor = NW)
    La_1.place(x = 30, y = 30)
    La_2 = Label(Ventana_About, text = Read("archivo_about.txt", 1), font = ("Consolas","15"), bg = "black", fg = "dark turquoise", anchor = NW)
    La_2.place(x = 30, y = 70)
    La_3 = Label(Ventana_About, text = Read("archivo_about.txt", 2), font = ("Consolas","15"), bg = "black", fg = "dark turquoise", anchor = NW)
    La_3.place(x = 30, y = 100)
    La_4 = Label(Ventana_About, text = Read("archivo_about.txt", 3), font = ("Consolas","12"), bg = "black", fg = "white", anchor = NW)
    La_4.place(x = 30, y = 130)
    La_5 = Label(Ventana_About, text = Read("archivo_about.txt", 4), font = ("Consolas","12"), bg = "black", fg = "white", anchor = NW)
    La_5.place(x = 30, y = 150)
    La_6 = Label(Ventana_About, text = Read("archivo_about.txt", 5), font = ("Consolas","15"), bg = "black", fg = "dark turquoise", anchor = NW)
    La_6.place(x = 30, y = 220)
    La_7 = Label(Ventana_About, text = Read("archivo_about.txt", 6), font = ("Consolas","12"), bg = "black", fg = "white", anchor = NW)
    La_7.place(x = 30, y = 250)
    La_8 = Label(Ventana_About, text = Read("archivo_about.txt", 7), font = ("Consolas","15"), bg = "black", fg = "dark turquoise", anchor = NW)
    La_8.place(x = 500, y = 220)
    La_9 = Label(Ventana_About, text = Read("archivo_about.txt", 8), font = ("Consolas","12"), bg = "black", fg = "white", anchor = NW)
    La_9.place(x = 500, y = 250)
    La_10 = Label(Ventana_About, text = Read("archivo_about.txt", 9), font = ("Consolas","12"), bg = "black", fg = "white", anchor = NW)
    La_10.place(x = 630, y = 120)
    La_11 = Label(Ventana_About, text = Read("archivo_about.txt", 10), font = ("Consolas","12"), bg = "black", fg = "white", anchor = NW)
    La_11.place(x = 630, y = 140)
    
    def Cerrar_about():
        Ventana_About.destroy()
        Ventana_Inicio.deiconify()
        
    # Botones para cambiar de ventana
    About_Cerrar_Button = Button(Canvas_About, text = "Regresar al menú", bg = "dark turquoise", fg = "black", command = Cerrar_about)
    About_Cerrar_Button.place(x = 720, y = 500)
    
    Ventana_About.mainloop()

    
### ========== VENTANA TABLA DE POSICIONES ========== ###

def Ventana_tabla():
    # Definir la ventana, su canvas y el tamaño respectivo
    global Ventana_Tabla, Canvas_Tabla
    Ventana_Inicio.withdraw()
    Ventana_Tabla = Toplevel()
    Ventana_Tabla.title("Tabla de Posiciones")
    Ventana_Tabla.minsize(950, 550)
    Ventana_Tabla.resizable(width = NO, height = NO)
    Canvas_Tabla = Canvas(Ventana_Tabla, width = 950, height = 550, bg = "dark grey")
    Canvas_Tabla.place(x = 0, y = 0)

    Imag_Fondo_Tabla = cargarimagen("About.png") 
    Fondo_Inicio = Canvas_Tabla.create_image(250,10, image = Imag_Fondo_Tabla, anchor = NW)

    Canvas_Tabla.create_text(400, 230, text="Pilotos", fill = "White", font = ("Consolas","18"),anchor =NW)
    Canvas_Tabla.create_text(385, 350, text="Automóviles", fill = "White", font = ("Consolas","18"),anchor =NW)

    # Botones para cambiar de ventana
    Ord_Des_RPG_Button = Button(Canvas_Tabla, text = "Ordenar RGP\nDescendente", bg = "dark turquoise", fg = "black", command = tabla_RPG_desc)
    Ord_Des_RPG_Button.place(x = 100, y = 270)
    Ord_As_RPG_Button = Button(Canvas_Tabla, text = "Ordenar RGP\nAscendente", bg = "dark turquoise", fg = "black", command = tabla_RPG)
    Ord_As_RPG_Button.place(x = 300, y = 270)
    Ord_Des_RPE_Button = Button(Canvas_Tabla, text = "Ordenar REP\nDescendente", bg = "dark turquoise", fg = "black", command = tabla_RPE_desc)
    Ord_Des_RPE_Button.place(x = 500, y = 270)
    Ord_As_RPE_Button = Button(Canvas_Tabla, text = "Ordenar REP\nAscendente", bg = "dark turquoise", fg = "black", command = tabla_RPE)
    Ord_As_RPE_Button.place(x = 700, y = 270)
    Ord_Des_Ef_Button = Button(Canvas_Tabla, text = "Ordenar Eficiencia\nDescendente", bg = "dark turquoise", fg = "black", command = tabla_carro_desc)
    Ord_Des_Ef_Button.place(x = 300, y = 450)
    Ord_As_Ef_Button = Button(Canvas_Tabla, text = "Ordenar Eficiencia\nAscendente", bg = "dark turquoise", fg = "black", command = tabla_carro)
    Ord_As_Ef_Button.place(x = 500, y = 450)
    Tabla_Cerrar_Button = Button(Canvas_Tabla, text = "Regresar al menú", bg = "black", fg = "white", command = Cerrar_tabla)
    Tabla_Cerrar_Button.place(x = 730, y = 500)

    Ventana_Tabla.mainloop()

def Cerrar_tabla():
    Ventana_Tabla.destroy()
    Ventana_Inicio.deiconify()


# Lista de todos los pilotos tomados de sus respectivos archivos de texto
LP = [[Read("Félix Da Costa.txt", 0), Read("Félix Da Costa.txt", 1), Read("Félix Da Costa.txt", 2), Read("Félix Da Costa.txt", 3), Read("Félix Da Costa.txt", 4), Read("Félix Da Costa.txt", 9),
       (calcular_RGP(to_Int(Read("Félix Da Costa.txt", 6)), to_Int(Read("Félix Da Costa.txt", 5)), to_Int(Read("Félix Da Costa.txt", 4)), to_Int(Read("Félix Da Costa.txt", 7)))),
       (calcular_REP(to_Int(Read("Félix Da Costa.txt", 6)), to_Int(Read("Félix Da Costa.txt", 4)), to_Int(Read("Félix Da Costa.txt", 7))))],
      [Read("Alexander Sims.txt", 0), Read("Alexander Sims.txt", 1), Read("Alexander Sims.txt", 2), Read("Alexander Sims.txt", 3), Read("Alexander Sims.txt", 4), Read("Alexander Sims.txt", 9),
       (calcular_RGP(to_Int(Read("Alexander Sims.txt", 6)), to_Int(Read("Alexander Sims.txt", 5)), to_Int(Read("Alexander Sims.txt", 4)), to_Int(Read("Alexander Sims.txt", 7)))),
       (calcular_REP(to_Int(Read("Alexander Sims.txt", 6)), to_Int(Read("Alexander Sims.txt", 4)), to_Int(Read("Alexander Sims.txt", 7))))],
      [Read("Lucas di Grassi.txt", 0), Read("Lucas di Grassi.txt", 1), Read("Lucas di Grassi.txt", 2), Read("Lucas di Grassi.txt", 3), Read("Lucas di Grassi.txt", 4), Read("Lucas di Grassi.txt", 9),
       (calcular_RGP(to_Int(Read("Lucas di Grassi.txt", 6)), to_Int(Read("Lucas di Grassi.txt", 5)), to_Int(Read("Lucas di Grassi.txt", 4)), to_Int(Read("Lucas di Grassi.txt", 7)))),
       (calcular_REP(to_Int(Read("Lucas di Grassi.txt", 6)), to_Int(Read("Lucas di Grassi.txt", 4)), to_Int(Read("Lucas di Grassi.txt", 7))))],
      [Read("Daniel Abt.txt", 0), Read("Daniel Abt.txt", 1), Read("Daniel Abt.txt", 2), Read("Daniel Abt.txt", 3), Read("Daniel Abt.txt", 4), Read("Daniel Abt.txt", 9),
       (calcular_RGP(to_Int(Read("Daniel Abt.txt", 6)), to_Int(Read("Daniel Abt.txt", 5)), to_Int(Read("Daniel Abt.txt", 4)), to_Int(Read("Daniel Abt.txt", 7)))),
       (calcular_REP(to_Int(Read("Daniel Abt.txt", 6)), to_Int(Read("Daniel Abt.txt", 4)), to_Int(Read("Daniel Abt.txt", 7))))],
      [Read("Jose Maria Lopez.txt", 0), Read("Jose Maria Lopez.txt", 1), Read("Jose Maria Lopez.txt", 2), Read("Jose Maria Lopez.txt", 3), Read("Jose Maria Lopez.txt", 4), Read("Jose Maria Lopez.txt", 9),
       (calcular_RGP(to_Int(Read("Jose Maria Lopez.txt", 6)), to_Int(Read("Jose Maria Lopez.txt", 5)), to_Int(Read("Jose Maria Lopez.txt", 4)), to_Int(Read("Jose Maria Lopez.txt", 7)))),
       (calcular_REP(to_Int(Read("Jose Maria Lopez.txt", 6)), to_Int(Read("Jose Maria Lopez.txt", 4)), to_Int(Read("Jose Maria Lopez.txt", 7))))],
      [Read("Max Gunther.txt", 0), Read("Max Gunther.txt", 1), Read("Max Gunther.txt", 2), Read("Max Gunther.txt", 3), Read("Max Gunther.txt", 4), Read("Max Gunther.txt", 9),
       (calcular_RGP(to_Int(Read("Max Gunther.txt", 6)), to_Int(Read("Max Gunther.txt", 5)), to_Int(Read("Max Gunther.txt", 4)), to_Int(Read("Max Gunther.txt", 7)))),
       (calcular_REP(to_Int(Read("Max Gunther.txt", 6)), to_Int(Read("Max Gunther.txt", 4)), to_Int(Read("Max Gunther.txt", 7))))],
      [Read("Sebastian Buemi.txt", 0), Read("Sebastian Buemi.txt", 1), Read("Sebastian Buemi.txt", 2), Read("Sebastian Buemi.txt", 3), Read("Sebastian Buemi.txt", 4), Read("Sebastian Buemi.txt", 9),
       (calcular_RGP(to_Int(Read("Sebastian Buemi.txt", 6)), to_Int(Read("Sebastian Buemi.txt", 5)), to_Int(Read("Sebastian Buemi.txt", 4)), to_Int(Read("Sebastian Buemi.txt", 7)))),
       (calcular_REP(to_Int(Read("Sebastian Buemi.txt", 6)), to_Int(Read("Sebastian Buemi.txt", 4)), to_Int(Read("Sebastian Buemi.txt", 7))))],
      [Read("Alex Lynn.txt", 0), Read("Alex Lynn.txt", 1), Read("Alex Lynn.txt", 2), Read("Alex Lynn.txt", 3), Read("Alex Lynn.txt", 4), Read("Alex Lynn.txt", 9),
       (calcular_RGP(to_Int(Read("Alex Lynn.txt", 6)), to_Int(Read("Alex Lynn.txt", 5)), to_Int(Read("Alex Lynn.txt", 4)), to_Int(Read("Alex Lynn.txt", 7)))),
       (calcular_REP(to_Int(Read("Alex Lynn.txt", 6)), to_Int(Read("Alex Lynn.txt", 4)), to_Int(Read("Alex Lynn.txt", 7))))],
      [Read("Mitch Evans.txt", 0), Read("Mitch Evans.txt", 1), Read("Mitch Evans.txt", 2), Read("Mitch Evans.txt", 3), Read("Mitch Evans.txt", 4), Read("Mitch Evans.txt", 9),
       (calcular_RGP(to_Int(Read("Mitch Evans.txt", 6)), to_Int(Read("Mitch Evans.txt", 5)), to_Int(Read("Mitch Evans.txt", 4)), to_Int(Read("Mitch Evans.txt", 7)))),
       (calcular_REP(to_Int(Read("Mitch Evans.txt", 6)), to_Int(Read("Mitch Evans.txt", 4)), to_Int(Read("Mitch Evans.txt", 7))))],
      [Read("Oliver Rowland.txt", 0), Read("Oliver Rowland.txt", 1), Read("Oliver Rowland.txt", 2), Read("Oliver Rowland.txt", 3), Read("Oliver Rowland.txt", 4), Read("Oliver Rowland.txt", 9),
       (calcular_RGP(to_Int(Read("Oliver Rowland.txt", 6)), to_Int(Read("Oliver Rowland.txt", 5)), to_Int(Read("Oliver Rowland.txt", 4)), to_Int(Read("Oliver Rowland.txt", 7)))),
       (calcular_REP(to_Int(Read("Oliver Rowland.txt", 6)), to_Int(Read("Oliver Rowland.txt", 4)), to_Int(Read("Oliver Rowland.txt", 7))))]]



### ==========   ORDENAMIENTO Y MUESTRA DE DATOS DE PILOTOS   ========== ###

def tabla_RPG():
    Canvas_Tabla_RPG1 = Canvas(Ventana_Tabla, width = 950, height = 550, bg = "grey")
    Canvas_Tabla_RPG1.place(x = 0, y = 0)
    nombres = ordenamiento(get_RPX(LP, 6), LP, 6)
    Canvas_Tabla_RPG1.create_text(350, 30, text="RGP Ascendente", fill = "dark turquoise", font = ("Consolas","18"),anchor =NW)
    Canvas_Tabla_RPG1.create_text(0, 75, text="___________________________________________________________________________________________", fill = "dark turquoise", font = ("Consolas","18"),anchor =NW)
    Canvas_Tabla_RPG1.create_text(60, 80, text="Nombre", fill = "White", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_RPG1.create_text(215, 80, text="Edad", fill = "White", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_RPG1.create_text(270, 80, text="Nacionalidad", fill = "White", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_RPG1.create_text(408, 80, text="Temporada", fill = "White", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_RPG1.create_text(520, 80, text="Compet.", fill = "White", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_RPG1.create_text(590, 80, text="Escudería", fill = "White", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_RPG1.create_text(700, 80, text="RGP", fill = "White", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_RPG1.create_text(780, 80, text="REP", fill = "White", font = ("Consolas","13"),anchor =NW)
    y = 120
    pos = 1
    # Ciclo que recorre la lista de pilotos y los asocia con su respectivo RGP
    for i in range(len(nombres)):
        for j in range(len(LP)):
            if nombres[i] == LP[j][0]:
                # Creación de texto desde archivos de texto
                Canvas_Tabla_RPG1.create_text(50, y, text=LP[j][0], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_RPG1.create_text(220, y, text=LP[j][1], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_RPG1.create_text(270, y, text=LP[j][2], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_RPG1.create_text(430, y, text=LP[j][3], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_RPG1.create_text(540, y, text=LP[j][4], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_RPG1.create_text(600, y, text=LP[j][5], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_RPG1.create_text(700, y, text=LP[j][6], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_RPG1.create_text(780, y, text=LP[j][7], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_RPG1.create_text(20, y, text=str(pos), fill = "White", font = ("Consolas","13"),anchor =NW)
                # Creación de botones
                if pos == 1:
                    Boton1 = Button(Canvas_Tabla_RPG1, text = "Ver", bg = "dark turquoise", fg = "black", command = lambda: Ventana_pilot(to_String(LP[j][0])+".txt")).place(x = 860, y = y)
                elif pos == 2:
                    Boton2 = Button(Canvas_Tabla_RPG1, text = "Ver", bg = "dark turquoise", fg = "black", command = lambda: Ventana_pilot(to_String(LP[j][0])+".txt")).place(x = 860, y = y)
                elif pos == 3:
                    Boton3 = Button(Canvas_Tabla_RPG1, text = "Ver", bg = "dark turquoise", fg = "black", command = lambda: Ventana_pilot(to_String(LP[j][0])+".txt")).place(x = 860, y = y)
                elif pos == 4:
                    Boton4 = Button(Canvas_Tabla_RPG1, text = "Ver", bg = "dark turquoise", fg = "black", command = lambda: Ventana_pilot(to_String(LP[j][0])+".txt")).place(x = 860, y = y)
                elif pos == 5:
                    Boton5 = Button(Canvas_Tabla_RPG1, text = "Ver", bg = "dark turquoise", fg = "black", command = lambda: Ventana_pilot(to_String(LP[j][0])+".txt")).place(x = 860, y = y)
                elif pos == 6:
                    Boton6 = Button(Canvas_Tabla_RPG1, text = "Ver", bg = "dark turquoise", fg = "black", command = lambda: Ventana_pilot(to_String(LP[j][0])+".txt")).place(x = 860, y = y)
                elif pos == 7:
                    Boton7 = Button(Canvas_Tabla_RPG1, text = "Ver", bg = "dark turquoise", fg = "black", command = lambda: Ventana_pilot(to_String(LP[j][0])+".txt")).place(x = 860, y = y)
                elif pos == 8:
                    Boton8 = Button(Canvas_Tabla_RPG1, text = "Ver", bg = "dark turquoise", fg = "black", command = lambda: Ventana_pilot(to_String(LP[j][0])+".txt")).place(x = 860, y = y)
                elif pos == 9:
                    Boton9 = Button(Canvas_Tabla_RPG1, text = "Ver", bg = "dark turquoise", fg = "black", command = lambda: Ventana_pilot(to_String(LP[j][0])+".txt")).place(x = 860, y = y)
                elif pos == 10:
                    Boton10 = Button(Canvas_Tabla_RPG1, text = "Ver", bg = "dark turquoise", fg = "black", command = lambda: Ventana_pilot(to_String(LP[j][0])+".txt")).place(x = 860, y = y)
                elif pos == 11:
                    Boton11 = Button(Canvas_Tabla_RPG1, text = "Ver", bg = "dark turquoise", fg = "black", command = lambda: Ventana_pilot(to_String(LP[j][0])+".txt")).place(x = 860, y = y)
                elif pos == 12:
                    Boton12 = Button(Canvas_Tabla_RPG1, text = "Ver", bg = "dark turquoise", fg = "black", command = lambda: Ventana_pilot(to_String(LP[j][0])+".txt")).place(x = 860, y = y)
                elif pos == 13:
                    Boton13 = Button(Canvas_Tabla_RPG1, text = "Ver", bg = "dark turquoise", fg = "black", command = lambda: Ventana_pilot(to_String(LP[j][0])+".txt")).place(x = 860, y = y)
                c = IntVar()
                R1 = Checkbutton(Canvas_Tabla_RPG1, font = ("Consolas", "12"), anchor = NW, variable = c).place(x = 910, y= y)
        y += 30
        pos += 1
    # Botones para cambiar de ventana
    Ord_Des_RPG_Button = Button(Canvas_Tabla_RPG1, text = "Ordenar RGP\nDescendente", bg = "dark turquoise", fg = "black", command = tabla_RPG_desc)
    Ord_Des_RPG_Button.place(x = 100, y = 500)
    Ord_Des_RPE_Button = Button(Canvas_Tabla_RPG1, text = "Ordenar REP\nDescendente", bg = "dark turquoise", fg = "black", command = tabla_RPE_desc)
    Ord_Des_RPE_Button.place(x = 500, y = 500)
    Ord_As_RPE_Button = Button(Canvas_Tabla_RPG1, text = "Ordenar REP\nAscendente", bg = "dark turquoise", fg = "black", command = tabla_RPE)
    Ord_As_RPE_Button.place(x = 700, y = 500)
    Crear_Piloto_Button = Button(Canvas_Tabla_RPG1, text ="Editar \n piloto" , bg = "black", fg = "dark turquoise", command = Ventana_crear_pilotos)
    Crear_Piloto_Button.place(x = 50, y = 20)
    Test_Button = Button(Canvas_Tabla_RPG1, text ="Ir a \n Test Drive" , bg = "black", fg = "dark turquoise", command = Ventana_test_drive)
    Test_Button.place(x = 830, y = 20)
    Tabla_Cerrar_Button = Button(Canvas_Tabla_RPG1, text = "Regresar", bg = "black", fg = "white", command = Cerrar_tabla)
    Tabla_Cerrar_Button.place(x = 730, y = 30)
    

def tabla_RPG_desc():
    Canvas_Tabla_RPG = Canvas(Ventana_Tabla, width = 950, height = 550, bg = "grey")
    Canvas_Tabla_RPG.place(x = 0, y = 0)
    nombres = invertir(ordenamiento(get_RPX(LP, 6), LP, 6))
    Canvas_Tabla_RPG.create_text(350, 30, text="RGP Descendente", fill = "dark turquoise", font = ("Consolas","18"),anchor =NW)
    Canvas_Tabla_RPG.create_text(0, 75, text="______________________________________________________________________________________", fill = "dark turquoise", font = ("Consolas","18"),anchor =NW)
    Canvas_Tabla_RPG.create_text(60, 80, text="Nombre", fill = "White", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_RPG.create_text(215, 80, text="Edad", fill = "White", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_RPG.create_text(270, 80, text="Nacionalidad", fill = "White", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_RPG.create_text(408, 80, text="Temporada", fill = "White", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_RPG.create_text(520, 80, text="Compet.", fill = "White", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_RPG.create_text(590, 80, text="Escudería", fill = "White", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_RPG.create_text(700, 80, text="RGP", fill = "White", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_RPG.create_text(780, 80, text="REP", fill = "White", font = ("Consolas","13"),anchor =NW)
    y = 120
    pos = 1
    # Ciclo que recorre la lista de pilotos y los asocia con su respectivo RGP
    for i in range(len(nombres)):
        for j in range(len(LP)):
            if nombres[i] == LP[j][0]:
                # Creación de texto desde archivos de texto
                Canvas_Tabla_RPG.create_text(50, y, text=LP[j][0], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_RPG.create_text(220, y, text=LP[j][1], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_RPG.create_text(270, y, text=LP[j][2], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_RPG.create_text(430, y, text=LP[j][3], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_RPG.create_text(540, y, text=LP[j][4], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_RPG.create_text(600, y, text=LP[j][5], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_RPG.create_text(700, y, text=LP[j][6], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_RPG.create_text(780, y, text=LP[j][7], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_RPG.create_text(20, y, text=str(pos), fill = "White", font = ("Consolas","13"),anchor =NW)
                Button1 = Button(Canvas_Tabla_RPG, text = "Ver", bg = "dark turquoise", fg = "black", command = lambda: Ventana_pilot(to_String(LP[j][0])+".txt")).place(x = 860, y = y)
                c = IntVar()
                R1 = Checkbutton(Canvas_Tabla_RPG, font = ("Consolas", "12"), anchor = NW, variable = c).place(x = 910, y= y)
        y += 30
        pos += 1

    # Botones para cambiar de ventana
    Ord_As_RPG_Button = Button(Canvas_Tabla_RPG, text = "Ordenar RGP\nAscendente", bg = "dark turquoise", fg = "black", command = tabla_RPG)
    Ord_As_RPG_Button.place(x = 300, y = 500)
    Ord_Des_RPE_Button = Button(Canvas_Tabla_RPG, text = "Ordenar REP\nDescendente", bg = "dark turquoise", fg = "black", command = tabla_RPE_desc)
    Ord_Des_RPE_Button.place(x = 500, y = 500)
    Ord_As_RPE_Button = Button(Canvas_Tabla_RPG, text = "Ordenar REP\nAscendente", bg = "dark turquoise", fg = "black", command = tabla_RPE)
    Ord_As_RPE_Button.place(x = 700, y = 500)
    Crear_Piloto_Button = Button(Canvas_Tabla_RPG,text ="Editar \n piloto" , bg = "black", fg = "dark turquoise", command = Ventana_crear_pilotos)
    Crear_Piloto_Button.place(x = 50, y = 20)
    Test_Button = Button(Canvas_Tabla_RPG,text ="Ir a \n Test Drive" , bg = "black", fg = "dark turquoise", command = Ventana_test_drive)
    Test_Button.place(x = 830, y = 20)
    Tabla_Cerrar_Button = Button(Canvas_Tabla_RPG, text = "Regresar", bg = "black", fg = "white", command = Cerrar_tabla)
    Tabla_Cerrar_Button.place(x = 730, y = 20)

def tabla_RPE():
    Canvas_Tabla_RPG = Canvas(Ventana_Tabla, width = 950, height = 550, bg = "grey")
    Canvas_Tabla_RPG.place(x = 0, y = 0)
    nombres = ordenamiento(get_RPX(LP, 7), LP, 7)
    Canvas_Tabla_RPG.create_text(350, 30, text="REP Ascendente", fill = "dark turquoise", font = ("Consolas","18"),anchor =NW)
    Canvas_Tabla_RPG.create_text(0, 75, text="_______________________________________________________________________________________", fill = "dark turquoise", font = ("Consolas","18"),anchor =NW)
    Canvas_Tabla_RPG.create_text(60, 80, text="Nombre", fill = "White", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_RPG.create_text(215, 80, text="Edad", fill = "White", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_RPG.create_text(270, 80, text="Nacionalidad", fill = "White", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_RPG.create_text(408, 80, text="Temporada", fill = "White", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_RPG.create_text(520, 80, text="Compet.", fill = "White", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_RPG.create_text(590, 80, text="Escudería", fill = "White", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_RPG.create_text(700, 80, text="RGP", fill = "White", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_RPG.create_text(780, 80, text="REP", fill = "White", font = ("Consolas","13"),anchor =NW)
    y = 120
    pos = 1
    # Ciclo que recorre la lista de pilotos y los asocia con su respectivo REP
    for i in range(len(nombres)):
        for j in range(len(LP)):
            if nombres[i] == LP[j][0]:
                # Creación de texto desde archivos de texto
                Canvas_Tabla_RPG.create_text(50, y, text=LP[j][0], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_RPG.create_text(220, y, text=LP[j][1], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_RPG.create_text(270, y, text=LP[j][2], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_RPG.create_text(430, y, text=LP[j][3], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_RPG.create_text(540, y, text=LP[j][4], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_RPG.create_text(600, y, text=LP[j][5], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_RPG.create_text(700, y, text=LP[j][6], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_RPG.create_text(780, y, text=LP[j][7], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_RPG.create_text(20, y, text=str(pos), fill = "White", font = ("Consolas","13"),anchor =NW)
                Button1 = Button(Canvas_Tabla_RPG, text = "Ver", bg = "dark turquoise", fg = "black", command = lambda: Ventana_pilot(to_String(LP[j][0])+".txt")).place(x = 860, y = y)
                c = IntVar()
                R1 = Checkbutton(Canvas_Tabla_RPG, font = ("Consolas", "12"), anchor = NW, variable = c).place(x = 910, y= y)
        y += 30
        pos += 1

    # Botones para cambiar de ventana
    Ord_As_RPG_Button = Button(Canvas_Tabla_RPG, text = "Ordenar RGP\nAscendente", bg = "dark turquoise", fg = "black", command = tabla_RPG)
    Ord_As_RPG_Button.place(x = 300, y = 500)
    Ord_Des_RPG_Button = Button(Canvas_Tabla_RPG, text = "Ordenar RGP\nDescendente", bg = "dark turquoise", fg = "black", command = tabla_RPG_desc)
    Ord_Des_RPG_Button.place(x = 100, y = 500)
    Ord_Des_RPE_Button = Button(Canvas_Tabla_RPG, text = "Ordenar REP\nDescendente", bg = "dark turquoise", fg = "black", command = tabla_RPE_desc)
    Ord_Des_RPE_Button.place(x = 500, y = 500)
    Crear_Piloto_Button = Button(Canvas_Tabla_RPG,text ="Editar \n piloto" , bg = "black", fg = "dark turquoise", command = Ventana_crear_pilotos)
    Crear_Piloto_Button.place(x = 50, y = 20)
    Test_Button = Button(Canvas_Tabla_RPG,text ="Ir a \n Test Drive" , bg = "black", fg = "dark turquoise", command = Ventana_test_drive)
    Test_Button.place(x = 830, y = 20)
    Tabla_Cerrar_Button = Button(Canvas_Tabla_RPG, text = "Regresar", bg = "black", fg = "white", command = Cerrar_tabla)
    Tabla_Cerrar_Button.place(x = 730, y = 20)

def tabla_RPE_desc():
    Canvas_Tabla_RPG = Canvas(Ventana_Tabla, width = 950, height = 550, bg = "grey")
    Canvas_Tabla_RPG.place(x = 0, y = 0)
    nombres = invertir(ordenamiento(get_RPX(LP, 7), LP, 7))
    Canvas_Tabla_RPG.create_text(350, 30, text="REP Descendente", fill = "dark turquoise", font = ("Consolas","18"),anchor =NW)
    Canvas_Tabla_RPG.create_text(0, 75, text="________________________________________________________________________________________", fill = "dark turquoise", font = ("Consolas","18"),anchor =NW)
    Canvas_Tabla_RPG.create_text(60, 80, text="Nombre", fill = "White", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_RPG.create_text(215, 80, text="Edad", fill = "White", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_RPG.create_text(270, 80, text="Nacionalidad", fill = "White", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_RPG.create_text(408, 80, text="Temporada", fill = "White", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_RPG.create_text(520, 80, text="Compet.", fill = "White", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_RPG.create_text(590, 80, text="Escudería", fill = "White", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_RPG.create_text(700, 80, text="RGP", fill = "White", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_RPG.create_text(780, 80, text="REP", fill = "White", font = ("Consolas","13"),anchor =NW)
    y = 120
    pos = 1
    # Ciclo que recorre la lista de pilotos y los asocia con su respectivo RGP
    for i in range(len(nombres)):
        for j in range(len(LP)):
            if nombres[i] == LP[j][0]:
                # Creación de texto desde archivos de texto
                Canvas_Tabla_RPG.create_text(50, y, text=LP[j][0], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_RPG.create_text(220, y, text=LP[j][1], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_RPG.create_text(270, y, text=LP[j][2], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_RPG.create_text(430, y, text=LP[j][3], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_RPG.create_text(540, y, text=LP[j][4], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_RPG.create_text(600, y, text=LP[j][5], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_RPG.create_text(700, y, text=LP[j][6], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_RPG.create_text(780, y, text=LP[j][7], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_RPG.create_text(20, y, text=str(pos), fill = "White", font = ("Consolas","13"),anchor =NW)
                Button1 = Button(Canvas_Tabla_RPG, text = "Ver", bg = "dark turquoise", fg = "black", command = lambda: Ventana_pilot(to_String(LP[j][0])+".txt")).place(x = 860, y = y)
                c = IntVar()
                R1 = Checkbutton(Canvas_Tabla_RPG, font = ("Consolas", "12"), anchor = NW, variable = c).place(x = 910, y= y)
        y += 30
        pos += 1

    # Botones para cambiar de ventana
    Ord_As_RPG_Button = Button(Canvas_Tabla_RPG, text = "Ordenar RGP\nAscendente", bg = "dark turquoise", fg = "black", command = tabla_RPG)
    Ord_As_RPG_Button.place(x = 300, y = 500)
    Ord_Des_RPG_Button = Button(Canvas_Tabla_RPG, text = "Ordenar RGP\nDescendente", bg = "dark turquoise", fg = "black", command = tabla_RPG_desc)
    Ord_Des_RPG_Button.place(x = 100, y = 500)
    Ord_As_RPE_Button = Button(Canvas_Tabla_RPG, text = "Ordenar REP\nAscendente", bg = "dark turquoise", fg = "black", command = tabla_RPE)
    Ord_As_RPE_Button.place(x = 700, y = 500)
    Crear_Piloto_Button = Button(Canvas_Tabla_RPG,text ="Editar \n piloto" , bg = "black", fg = "dark turquoise", command = Ventana_crear_pilotos)
    Crear_Piloto_Button.place(x = 50, y = 20)
    Test_Button = Button(Canvas_Tabla_RPG,text ="Ir a \n Test Drive" , bg = "black", fg = "dark turquoise", command = Ventana_test_drive)
    Test_Button.place(x = 830, y = 20)
    Tabla_Cerrar_Button = Button(Canvas_Tabla_RPG, text = "Regresar", bg = "black", fg = "white", command = Cerrar_tabla)
    Tabla_Cerrar_Button.place(x = 730, y = 20)

# Lista de todos los autos
LA = [[Read("A-BMW.txt", 0), Read("A-BMW.txt", 1), Read("A-BMW.txt", 3), Read("A-BMW.txt", 11), Read("A-BMW.txt", 12)],
      [Read("A-ABT.txt", 0), Read("A-ABT.txt", 1), Read("A-ABT.txt", 3), Read("A-ABT.txt", 11), Read("A-ABT.txt", 12)],
      [Read("A-Geox.txt", 0), Read("A-Geox.txt", 1), Read("A-Geox.txt", 3), Read("A-Geox.txt", 11), Read("A-Geox.txt", 12)],
      [Read("A-Nissan.txt", 0), Read("A-Nissan.txt", 1), Read("A-Nissan.txt", 3), Read("A-Nissan.txt", 11), Read("A-Nissan.txt", 12)],
      [Read("A-Jaguar.txt", 0), Read("A-Jaguar.txt", 1), Read("A-Jaguar.txt", 3), Read("A-Jaguar.txt", 11), Read("A-Jaguar.txt", 12)]]

### ========== ORDENAMIENTO Y MUESTRA DE DATOS DE AUTOS ========== ###

def tabla_carro():
    Ventana_Tabla5 = Toplevel()
    Ventana_Tabla5.title("Tabla de Posiciones")
    Ventana_Tabla5.minsize(950, 550)
    Ventana_Tabla5.resizable(width = NO, height = NO)
    Canvas_Tabla_Carro5 = Canvas(Ventana_Tabla5, width = 950, height = 550, bg = "white")
    Canvas_Tabla_Carro5.place(x = 0, y = 0)
    nombres = ordenamiento(get_RPX(LA, 3), LA, 3)
    Canvas_Tabla_Carro5.create_text(350, 30, text="Eficiencia Ascendente", fill = "dark turquoise", font = ("Consolas","18"),anchor =NW)
    Canvas_Tabla_Carro5.create_text(0, 75, text="___________________________________________________________________________________________", fill = "dark turquoise", font = ("Consolas","18"),anchor =NW)
    Canvas_Tabla_Carro5.create_text(60, 80, text="Marca", fill = "Black", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_Carro5.create_text(215, 80, text="Modelo", fill = "Black", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_Carro5.create_text(350, 80, text="Temporada", fill = "Black", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_Carro5.create_text(520, 80, text="Eficiencia", fill = "Black", font = ("Consolas","13"),anchor =NW)
    
    y = 135
    y2 = 120
    pos = 1
    for i in range(len(nombres)):
        for j in range(len(LA)):
            if nombres[i] == LA[j][0]:
                # Creación de texto e imágenes desde archivos de texto
                Canvas_Tabla_Carro5.create_text(50, y, text=LA[j][0], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_Carro5.create_text(220, y, text=LA[j][1], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_Carro5.create_text(365, y, text=LA[j][2], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_Carro5.create_text(530, y, text=LA[j][3], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_Carro5.create_text(20, y, text=str(pos), fill = "Grey", font = ("Consolas","13"),anchor =NW)
                if pos == 1:
                    I5 = cargarimagen(LA[j][4])
                    Canvas_Tabla_Carro5.create_image(650,y2, image = I5, anchor = NW)
                elif pos == 2:
                    I6 = cargarimagen(LA[j][4])
                    Canvas_Tabla_Carro5.create_image(650,y2, image = I6, anchor = NW)
                elif pos == 3:
                    I7 = cargarimagen(LA[j][4])
                    Canvas_Tabla_Carro5.create_image(650,y2, image = I7, anchor = NW)
                elif pos == 4:
                    I8 = cargarimagen(LA[j][4])
                    Canvas_Tabla_Carro5.create_image(650,y2, image = I8, anchor = NW)
                elif pos == 5:
                    I9 = cargarimagen(LA[j][4])
                    Canvas_Tabla_Carro5.create_image(650,y2, image = I9, anchor = NW)
                elif pos == 6:
                    I0 = cargarimagen(LA[j][4])
                    Canvas_Tabla_Carro5.create_image(650,y2, image = I0, anchor = NW)
        y += 50
        y2 += 50
        pos += 1

    # Botones para cambiar de ventana
    Ord_Des_RPE_Button = Button(Canvas_Tabla_Carro5, text = "Ordenar Eficiencia\nDescendente", bg = "dark turquoise", fg = "black", command = tabla_carro_desc)
    Ord_Des_RPE_Button.place(x = 700, y = 500)

    def Cerrar_tabla_carro():
        Ventana_Tabla5.destroy()
        Ventana_Tabla.deiconify()
        
    Tabla_Cerrar_Button = Button(Canvas_Tabla_Carro5, text = "Regresar", bg = "black", fg = "white", command = Cerrar_tabla_carro)
    Tabla_Cerrar_Button.place(x = 730, y = 20)

    Ventana_Tabla5.mainloop()


def tabla_carro_desc():
    Ventana_Tabla6 = Toplevel()
    Ventana_Tabla6.title("Tabla de Posiciones")
    Ventana_Tabla6.minsize(950, 550)
    Ventana_Tabla6.resizable(width = NO, height = NO)
    Canvas_Tabla_Carro6 = Canvas(Ventana_Tabla6, width = 950, height = 550, bg = "grey")
    Canvas_Tabla_Carro6.place(x = 0, y = 0)
    nombres = invertir(ordenamiento(get_RPX(LA, 3), LA, 3))
    Canvas_Tabla_Carro6.create_text(350, 30, text="Eficiencia Descendente", fill = "dark turquoise", font = ("Consolas","18"),anchor =NW)
    Canvas_Tabla_Carro6.create_text(0, 75, text="_____________________________________________________________________________________________________________________________________________________", fill = "dark turquoise", font = ("Consolas","18"),anchor =NW)
    Canvas_Tabla_Carro6.create_text(60, 80, text="Marca", fill = "White", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_Carro6.create_text(215, 80, text="Modelo", fill = "White", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_Carro6.create_text(350, 80, text="Temporada", fill = "White", font = ("Consolas","13"),anchor =NW)
    Canvas_Tabla_Carro6.create_text(520, 80, text="Eficiencia", fill = "White", font = ("Consolas","13"),anchor =NW)
    y = 135
    y2 = 120
    pos = 1
    for i in range(len(nombres)):
        for j in range(len(LA)):
            if nombres[i] == LA[j][0]:
                # Creación de texto desde archivos de texto
                Canvas_Tabla_Carro6.create_text(50, y, text=LA[j][0], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_Carro6.create_text(220, y, text=LA[j][1], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_Carro6.create_text(365, y, text=LA[j][2], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_Carro6.create_text(530, y, text=LA[j][3], fill = "Black", font = ("Consolas","13"),anchor =NW)
                Canvas_Tabla_Carro6.create_text(20, y, text=str(pos), fill = "White", font = ("Consolas","13"),anchor =NW)
                if pos == 1:
                    I5 = cargarimagen(LA[j][4])
                    Canvas_Tabla_Carro6.create_image(600,y2, image = I5, anchor = NW)
                elif pos == 2:
                    I6 = cargarimagen(LA[j][4])
                    Canvas_Tabla_Carro6.create_image(600,y2, image = I6, anchor = NW)
                elif pos == 3:
                    I7 = cargarimagen(LA[j][4])
                    Canvas_Tabla_Carro6.create_image(600,y2, image = I7, anchor = NW)
                elif pos == 4:
                    I8 = cargarimagen(LA[j][4])
                    Canvas_Tabla_Carro6.create_image(600,y2, image = I8, anchor = NW)
                elif pos == 5:
                    I9 = cargarimagen(LA[j][4])
                    Canvas_Tabla_Carro6.create_image(600,y2, image = I9, anchor = NW)
        y2 += 50
        y += 50
        pos += 1

    # Botones para cambiar de ventana
    Ord_As_RPE_Button = Button(Canvas_Tabla_Carro6, text = "Ordenar Eficiencia\nAscendente", bg = "dark turquoise", fg = "black", command = tabla_carro)
    Ord_As_RPE_Button.place(x = 700, y = 500)

    def Cerrar_tabla_carro_desc():
        Ventana_Tabla6.destroy()
        Ventana_Tabla.deiconify()
        
    Tabla_Cerrar_Button = Button(Canvas_Tabla_Carro6, text = "Regresar", bg = "black", fg = "white", command = Cerrar_tabla_carro_desc)
    Tabla_Cerrar_Button.place(x = 730, y = 20)

    Ventana_Tabla6.mainloop()



### ========== VENTANA ESCUDERÍAS ========== ###

def Ventana_escuderias():
    # Definir la ventana, su canvas y el tamaño respectivo
    global Ventana_Escuderias, Canvas_Escuderias
    Ventana_Inicio.withdraw()
    Ventana_Escuderias = Toplevel()
    Ventana_Escuderias.title("Escuderías")
    Ventana_Escuderias.minsize(850, 550)
    Ventana_Escuderias.resizable(width = NO, height = NO)
    Canvas_Escuderias = Canvas(Ventana_Escuderias, width = 850, height = 550, bg = "snow")
    Canvas_Escuderias.place(x = 0, y = 0)

    # Crear imágenes desde archivos de texto
    Imag0_Escuderias = cargarimagen("Formula_E_Logo.png") 
    Imagen0_Escuderias = Canvas_Escuderias.create_image(400, 450, image = Imag0_Escuderias, anchor = NW)
    Imag11_Escuderias = cargarimagen(Read("archivo_bmw.txt", 4)) 
    Imagen11_Escuderias = Canvas_Escuderias.create_image(630, 40, image = Imag11_Escuderias, anchor = NW)
    Imag22_Escuderias = cargarimagen(Read("ABT.txt", 4))
    Imagen22_Escuderias = Canvas_Escuderias.create_image(630, 110, image = Imag22_Escuderias, anchor = NW)
    Imag33_Escuderias = cargarimagen(Read("Geox.txt", 4)) 
    Imagen33_Escuderias = Canvas_Escuderias.create_image(630, 170, image = Imag33_Escuderias, anchor = NW)
    Imag44_Escuderias = cargarimagen(Read("Nissan.txt", 4))
    Imagen44_Escuderias = Canvas_Escuderias.create_image(630, 240, image = Imag44_Escuderias, anchor = NW)
    Imag55_Escuderias = cargarimagen(Read("Jaguar.txt", 4)) 
    Imagen55_Escuderias = Canvas_Escuderias.create_image(630, 300, image = Imag55_Escuderias, anchor = NW)

    # Creación de texto desde archivos de texto
    Canvas_Escuderias.create_text(50, 60, text=Read("archivo_bmw.txt", 0), fill = "Black", font = ("Consolas","16"),anchor =NW)
    Canvas_Escuderias.create_text(30, 60, text=Read("archivo_bmw.txt", 2), fill = "Black", font = ("Consolas","16"),anchor =NW)
    Canvas_Escuderias.create_text(400, 60, text=Read("archivo_bmw.txt", 1), fill = "Black", font = ("Consolas","16"),anchor =NW)
    Canvas_Escuderias.create_text(50, 120, text=Read("ABT.txt", 0), fill = "Black", font = ("Consolas","16"),anchor =NW)
    Canvas_Escuderias.create_text(30, 120, text=Read("ABT.txt", 2), fill = "Black", font = ("Consolas","16"),anchor =NW)
    Canvas_Escuderias.create_text(400, 120, text=Read("ABT.txt", 1), fill = "Black", font = ("Consolas","16"),anchor =NW)
    Canvas_Escuderias.create_text(50, 180, text=Read("Geox.txt", 0), fill = "Black", font = ("Consolas","16"),anchor =NW)
    Canvas_Escuderias.create_text(30, 180, text=Read("Geox.txt", 2), fill = "Black", font = ("Consolas","16"),anchor =NW)
    Canvas_Escuderias.create_text(400, 180, text=Read("Geox.txt", 1), fill = "Black", font = ("Consolas","16"),anchor =NW)
    Canvas_Escuderias.create_text(50, 240, text=Read("Nissan.txt", 0), fill = "Black", font = ("Consolas","16"),anchor =NW)
    Canvas_Escuderias.create_text(30, 240, text=Read("Nissan.txt", 2), fill = "Black", font = ("Consolas","16"),anchor =NW)
    Canvas_Escuderias.create_text(400, 240, text=Read("Nissan.txt", 1), fill = "Black", font = ("Consolas","16"),anchor =NW)
    Canvas_Escuderias.create_text(50, 300, text=Read("Jaguar.txt", 0), fill = "Black", font = ("Consolas","16"),anchor =NW)
    Canvas_Escuderias.create_text(30, 300, text=Read("Jaguar.txt", 2), fill = "Black", font = ("Consolas","16"),anchor =NW)
    Canvas_Escuderias.create_text(400, 300, text=Read("Jaguar.txt", 1), fill = "Black", font = ("Consolas","16"),anchor =NW)
    Poner_Texto_Escud()

    # Botones para cambiar de ventana
    Crear_Escuderias_Button = Button(Canvas_Escuderias,text ="Crear nueva \n escudería" , bg = "dark turquoise", fg = "black", command = Ventana_crear_escuderias)
    Crear_Escuderias_Button.place(x = 30, y = 490)

    def Cerrar_escuderias():
        Ventana_Escuderias.destroy()
        Ventana_Inicio.deiconify()

    Escuderias_Cerrar_Button = Button(Canvas_Escuderias, text = "Regresar al menú", bg = "black", fg = "white", command = Cerrar_escuderias)
    Escuderias_Cerrar_Button.place(x = 720, y = 500)

    Ventana_Escuderias.mainloop() 


### ========== VENTANA CREAR PILOTOS ========== ###

def Ventana_crear_pilotos():
    # Definir la ventana, su canvas y el tamaño respectivo
    Ventana_Inicio.withdraw()
    Ventana_Crear_Pilotos = Toplevel()
    Ventana_Crear_Pilotos.title("Crear Pilotos")
    Ventana_Crear_Pilotos.minsize(550, 350)
    Ventana_Crear_Pilotos.resizable(width = NO, height = NO)
    Canvas_Crear_Pilotos = Canvas(Ventana_Crear_Pilotos, width = 550, height = 350, bg = "light grey")
    Canvas_Crear_Pilotos.place(x = 0, y = 0)

    Canvas_Crear_Pilotos.create_text(145, 10, text="Agregar nuevo piloto", fill = "dark turquoise", font = ("Arial black","18"),anchor =NW)

    # Entrys para obtener la información proporcionada por el usuario
    global E1, E2, E3, E4, E5, E6, E7, E8, E9, E10
    Canvas_Crear_Pilotos.create_text(20, 70, text="Nombre", font = ("Consolas","13"),anchor =NW)
    E1 = Entry(Canvas_Crear_Pilotos,font=("Consolas",13), width=20 ,bg="white",fg="black")
    E1.place(x=130,y=70)
    Canvas_Crear_Pilotos.create_text(365, 70, text="Edad", font = ("Consolas","13"),anchor =NW)
    E2 = Entry(Canvas_Crear_Pilotos,font=("Consolas",13), width=5 ,bg="white",fg="black")
    E2.place(x=460,y=70)
    Canvas_Crear_Pilotos.create_text(20, 100, text="Nacionalidad", font = ("Consolas","13"),anchor =NW)
    E3 = Entry(Canvas_Crear_Pilotos,font=("Consolas",13), width=20 ,bg="white",fg="black")
    E3.place(x=130,y=100)
    Canvas_Crear_Pilotos.create_text(365, 100, text="Año de\ntemporada", font = ("Consolas","12"),anchor =NW)    
    E4 = Entry(Canvas_Crear_Pilotos,font=("Consolas",13), width=5 ,bg="white",fg="black")
    E4.place(x=460,y=110)
    Canvas_Crear_Pilotos.create_text(20, 130, text="Escudería", font = ("Consolas","13"),anchor =NW)    
    E10 = Entry(Canvas_Crear_Pilotos,font=("Consolas",13), width=20 ,bg="white",fg="black")
    E10.place(x=130,y=130)
    Canvas_Crear_Pilotos.create_text(365, 140, text="Número de\npiloto", font = ("Consolas","12"),anchor =NW)
    E9 = Entry(Canvas_Crear_Pilotos,font=("Consolas",13), width=5 ,bg="white",fg="black")
    E9.place(x=460,y=150)
    
    Canvas_Crear_Pilotos.create_text(20, 160, text="Competencias:", font = ("Consolas","13"),anchor =NW)
    
    Canvas_Crear_Pilotos.create_text(40, 190, text="Total", font = ("Consolas","13"),anchor =NW)
    E5 = Entry(Canvas_Crear_Pilotos,font=("Consolas",13), width=5 ,bg="white",fg="black")
    E5.place(x=130,y=190)
    Canvas_Crear_Pilotos.create_text(40, 220, text="Podios", font = ("Consolas","13"),anchor =NW)
    E6 = Entry(Canvas_Crear_Pilotos,font=("Consolas",13), width=5 ,bg="white",fg="black")
    E6.place(x=130,y=220)
    Canvas_Crear_Pilotos.create_text(40, 250, text="Victorias", font = ("Consolas","13"),anchor =NW)
    E7 = Entry(Canvas_Crear_Pilotos,font=("Consolas",13), width=5 ,bg="white",fg="black")
    E7.place(x=130,y=250)
    Canvas_Crear_Pilotos.create_text(40, 280, text="Abandonos", font = ("Consolas","13"),anchor =NW)
    E8 = Entry(Canvas_Crear_Pilotos,font=("Consolas",13), width=5 ,bg="white",fg="black")
    E8.place(x=130,y=280)

    # Botones para cambiar de ventana
    Agregar_Piloto_Button = Button(Canvas_Crear_Pilotos, text = "Agregar", bg = "black", fg = "white", command = Agregar_piloto)
    Agregar_Piloto_Button.place(x = 300, y = 290)
    Agregar_Piloto_Button = Button(Canvas_Crear_Pilotos, text = "Editar", bg = "black", fg = "white", command = Editar_piloto)
    Agregar_Piloto_Button.place(x = 300, y = 320)
    
    def Cerrar_crear_pilotos():
        Ventana_Crear_Pilotos.destroy()
        Ventana_Inicio.deiconify()

    Crear_Pilotos_Cerrar_Button = Button(Canvas_Crear_Pilotos, text = "Regresar a \n la escudería", bg = "black", fg = "white", command = Cerrar_crear_pilotos)
    Crear_Pilotos_Cerrar_Button.place(x = 460, y = 290)

    Ventana_Crear_Pilotos.mainloop()
        
"""
Función para agregar un nuevo piloto.
Toma los datos que el usuario ingresa en los entry, crea un
archivo de texto y los escribe en el mismo.
Crea un nuevo piloto que se agrega a la lista de todos los demás.
Evalúa si el piloto pertenece a la escudería principal (BMW), de ser así
lo agrega a la pantalla principal y a la lista que se toma en cuenta
para calcular el índice ganador de la escudería.
"""

def Agregar_piloto():
    archivo = str(E9.get())+"P"+".txt"
    yval = int(E9.get())*30 + 215
    archivo_write = open(archivo, "w")
    Nombre = str(E1.get())+ "\n"
    archivo_write.write(Nombre)
    Edad = str(E2.get())+ "\n"
    archivo_write.write(Edad)
    Nacio = str(E3.get())+ "\n"
    archivo_write.write(Nacio)
    Año = str(E4.get())+ "\n"
    archivo_write.write(Año)
    tot = str(E5.get())+ "\n"
    archivo_write.write(tot)
    pod = str(E6.get())+ "\n"
    archivo_write.write(pod)
    vic = str(E7.get())+ "\n"
    archivo_write.write(vic)
    fall = str(E8.get())+ "\n"
    archivo_write.write(fall)
    num = str(E9.get())+ "\n"
    archivo_write.write(num)
    esc = str(E10.get())+ "\n"
    archivo_write.write(esc)
    RPG = (int(E7.get())+int(E6.get()))*100/(int(E5.get())-int(E8.get()))
    archivo_write.write(str(RPG))
    REP = int(E7.get())*100/(int(E5.get())-int(E8.get()))
    archivo_write.write(str(REP))
    archivo_write.close()
    Piloto_Nuevo = [E1.get(), E2.get(), E3.get(), E4.get(), int(E5.get()), E10.get(), RPG, REP]
    LP.append(Piloto_Nuevo)
    if str(E10.get()) == "BMW":
        Piloto_BMW = [int(E5.get()), int(E7.get())]
        IND.append(Piloto_BMW)
        Li_3 = Label(Ventana_Inicio, text = Indice_Ganador_Escuderia(IND), bg = "black", fg = "White", font = ("Consolas","15"), anchor = NW).place(x = 730, y = 90)
        try:
            Canvas_Inicio.create_text(530, 220, text=Read("3P.txt", 0), fill = "White", font = ("Consolas","15"),anchor =NW)
            Canvas_Inicio.create_text(510, 220, text=Read("3P.txt", 8), fill = "White", font = ("Consolas","15"),anchor =NW)
        except:
            pass
        try:
            Canvas_Inicio.create_text(530, 250, text=Read("4P.txt", 0), fill = "White", font = ("Consolas","15"),anchor =NW)
            Canvas_Inicio.create_text(510, 250, text=Read("4P.txt", 8), fill = "White", font = ("Consolas","15"),anchor =NW)
        except:
            pass
        try:
            Canvas_Inicio.create_text(530, 280, text=Read("5P.txt", 0), fill = "White", font = ("Consolas","15"),anchor =NW)
            Canvas_Inicio.create_text(510, 280, text=Read("5P.txt", 8), fill = "White", font = ("Consolas","15"),anchor =NW)
        except:
            pass

"""
Función para editar los datos de un piloto.
Toma los datos que el usuario ingresa en los entry, ingresa al
archivo del piloto y sobreescribe los nuevos datos en él.
"""
def Editar_piloto():
    archivo = str(E1.get())+".txt"
    yval = int(E9.get())*30 + 215
    archivo_write = open(archivo, "w")
    Nombre = str(E1.get())+ "\n"
    archivo_write.write(Nombre)
    Edad = str(E2.get())+ "\n"
    archivo_write.write(Edad)
    Nacio = str(E3.get())+ "\n"
    archivo_write.write(Nacio)
    Año = str(E4.get())+ "\n"
    archivo_write.write(Año)
    tot = str(E5.get())+ "\n"
    archivo_write.write(tot)
    pod = str(E6.get())+ "\n"
    archivo_write.write(pod)
    vic = str(E7.get())+ "\n"
    archivo_write.write(vic)
    fall = str(E8.get())+ "\n"
    archivo_write.write(fall)
    num = str(E9.get())+ "\n"
    archivo_write.write(num)
    esc = str(E10.get())+ "\n"
    archivo_write.write(esc)
    RPG = (int(E7.get())+int(E6.get()))*100/(int(E5.get())-int(E8.get()))
    archivo_write.write(str(RPG))
    REP = int(E7.get())*100/(int(E5.get())-int(E8.get()))
    archivo_write.write(str(REP))
    archivo_write.close()

### ========== VENTANA CREAR AUTOS ========== ###

def Ventana_crear_autos():
    # Definir la ventana, su canvas y el tamaño respectivo
    Ventana_Inicio.withdraw()
    Ventana_Crear_Autos = Toplevel()
    Ventana_Crear_Autos.title("Crear Autos")
    Ventana_Crear_Autos.minsize(550, 350)
    Ventana_Crear_Autos.resizable(width = NO, height = NO)
    Canvas_Crear_Autos = Canvas(Ventana_Crear_Autos, width = 550, height = 350, bg = "light grey")
    Canvas_Crear_Autos.place(x = 0, y = 0)

    Canvas_Crear_Autos.create_text(145, 10, text="Agregar nuevo auto", fill = "dark turquoise", font = ("Arial black","18"),anchor =NW)

    # Entrys para obtener la información proporcionada por el usuario
    global En1, En2, En3, En4, En5, En6, En7, En8, En9, En10, En11, En12
    Canvas_Crear_Autos.create_text(20, 70, text="Marca", font = ("Consolas","13"),anchor =NW)
    En1 = Entry(Canvas_Crear_Autos,font=("Consolas",13), width=15 ,bg="white",fg="black")
    En1.place(x=100,y=70)
    Canvas_Crear_Autos.create_text(20, 100, text="Modelo", font = ("Consolas","13"),anchor =NW)
    En2 = Entry(Canvas_Crear_Autos,font=("Consolas",13), width=15 ,bg="white",fg="black")
    En2.place(x=100,y=100)
    Canvas_Crear_Autos.create_text(20, 130, text="País", font = ("Consolas","13"),anchor =NW)
    En3 = Entry(Canvas_Crear_Autos,font=("Consolas",13), width=15 ,bg="white",fg="black")
    En3.place(x=100,y=130)
    Canvas_Crear_Autos.create_text(300, 70, text="Año de temporada", font = ("Consolas","13"),anchor =NW)    
    En4 = Entry(Canvas_Crear_Autos,font=("Consolas",13), width=5 ,bg="white",fg="black")
    En4.place(x=460,y=70)    
    Canvas_Crear_Autos.create_text(300, 100, text="Cantidad baterías", font = ("Consolas","13"),anchor =NW)
    En5 = Entry(Canvas_Crear_Autos,font=("Consolas",13), width=5 ,bg="white",fg="black")
    En5.place(x=460,y=100)
    Canvas_Crear_Autos.create_text(300, 130, text="Pilas por batería", font = ("Consolas","13"),anchor =NW)
    En6 = Entry(Canvas_Crear_Autos,font=("Consolas",13), width=5 ,bg="white",fg="black")
    En6.place(x=460,y=130)
    Canvas_Crear_Autos.create_text(300, 160, text="Nivel de tensión", font = ("Consolas","13"),anchor =NW)
    En7 = Entry(Canvas_Crear_Autos,font=("Consolas",13), width=5 ,bg="white",fg="black")
    En7.place(x=460,y=160)
    Canvas_Crear_Autos.create_text(20, 160, text="Estado", font = ("Consolas","13"),anchor =NW)
    En8 = Entry(Canvas_Crear_Autos,font=("Consolas",13), width=15 ,bg="white",fg="black")
    En8.place(x=100,y=160)
    Canvas_Crear_Autos.create_text(20, 220, text="Consumo\nmotores", font = ("Consolas","13"),anchor =NW)
    En9 = Entry(Canvas_Crear_Autos,font=("Consolas",13), width=15 ,bg="white",fg="black")
    En9.place(x=100,y=230)
    Canvas_Crear_Autos.create_text(20, 190, text="Sensores", font = ("Consolas","13"),anchor =NW)
    En10 = Entry(Canvas_Crear_Autos,font=("Consolas",13), width=15 ,bg="white",fg="black")
    En10.place(x=100,y=190)
    Canvas_Crear_Autos.create_text(300, 190, text="Peso", font = ("Consolas","13"),anchor =NW)
    En11 = Entry(Canvas_Crear_Autos,font=("Consolas",13), width=5 ,bg="white",fg="black")
    En11.place(x=460,y=190)
    Canvas_Crear_Autos.create_text(300, 220, text="Número de auto", font = ("Consolas","13"),anchor =NW)
    En12 = Entry(Canvas_Crear_Autos,font=("Consolas",13), width=5 ,bg="white",fg="black")
    En12.place(x=460,y=220)

    # Botones para cambiar de ventana
    Agregar_Auto_Button = Button(Canvas_Crear_Autos, text = "Crear auto", bg = "black", fg = "white", command = Agregar_auto)
    Agregar_Auto_Button.place(x = 385, y = 290)

    
    def Cerrar_crear_autos():
        Ventana_Crear_Autos.destroy()
        Ventana_Inicio.deiconify()

    Crear_Autos_Cerrar_Button = Button(Canvas_Crear_Autos, text = "Regresar a \n la escudería", bg = "black", fg = "white", command = Cerrar_crear_autos)
    Crear_Autos_Cerrar_Button.place(x = 460, y = 290)

    Ventana_Crear_Autos.mainloop()
    
"""
Función para agregar un nuevo auto tras una temporada.
Toma los datos que el usuario ingresa en los entry, crea un archivo de
texto y los escribe en el mismo.
Crea un nuevo auto que se agrega a la lista de todos los demás.
Evalúa si el auto pertenece a la escudería principal (BMW), de ser
así lo agrega a la pantalla principal.
"""

def Agregar_auto():
    archivo = str(En12.get())+"A"+".txt"
    yval = int(En12.get())*30 + 360
    archivo_write = open(archivo, "w")
    Marca = str(En1.get())+ "\n"
    archivo_write.write(Marca)
    Modelo = str(En2.get())+ "\n"
    archivo_write.write(Modelo)
    Pais = str(En3.get())+ "\n"
    archivo_write.write(Pais)
    Año = str(En4.get())+ "\n"
    archivo_write.write(Año)
    bat = str(En5.get())+ "\n"
    archivo_write.write(bat)
    pilas = str(En6.get())+ "\n"
    archivo_write.write(pilas)
    tens = str(En7.get())+ "\n"
    archivo_write.write(tens)
    estado = str(En8.get())+ "\n"
    archivo_write.write(estado)
    mot = str(En9.get())+ "\n"
    archivo_write.write(mot)
    sens = str(En10.get())+ "\n"
    archivo_write.write(sens)
    peso = str(En11.get())+ "\n"
    archivo_write.write(peso)
    num = str(En12.get())+ "\n"
    archivo_write.write(num)
    archivo_write.close()
    Li_4 = Label(Ventana_Inicio, text = int(En4.get()), bg = "black", fg = "White", font = ("Consolas","15"), anchor = NW).place(x = 530, y = 60)
    nuevo_auto = [En1.get(), En2.get(), En4.get(), int(En9.get())]
    LA.append(nuevo_auto)
    if str(En1.get()) == "BMW":
        try:
            Canvas_Inicio.create_text(510, 360, text=Read("2A.txt", 11), fill = "White", font = ("Consolas","15"),anchor =NW)
            Canvas_Inicio.create_text(540, 360, text=Read("2A.txt", 3), fill = "White", font = ("Consolas","15"),anchor =NW)
            Canvas_Inicio.create_text(610, 360, text=Read("2A.txt", 0), fill = "White", font = ("Consolas","15"),anchor =NW)
            Canvas_Inicio.create_text(680, 360, text=Read("2A.txt", 1), fill = "White", font = ("Consolas","15"),anchor =NW)
        except:
            pass
        try:
            Canvas_Inicio.create_text(510, 390, text=Read("3A.txt", 11), fill = "White", font = ("Consolas","15"),anchor =NW)
            Canvas_Inicio.create_text(540, 390, text=Read("3A.txt", 3), fill = "White", font = ("Consolas","15"),anchor =NW)
            Canvas_Inicio.create_text(610, 390, text=Read("3A.txt", 0), fill = "White", font = ("Consolas","15"),anchor =NW)
            Canvas_Inicio.create_text(680, 390, text=Read("3A.txt", 1), fill = "White", font = ("Consolas","15"),anchor =NW)
        except:
            pass
        try:
            Canvas_Inicio.create_text(510, 420, text=Read("4A.txt", 11), fill = "White", font = ("Consolas","15"),anchor =NW)
            Canvas_Inicio.create_text(540, 420, text=Read("4A.txt", 3), fill = "White", font = ("Consolas","15"),anchor =NW)
            Canvas_Inicio.create_text(610, 420, text=Read("4A.txt", 0), fill = "White", font = ("Consolas","15"),anchor =NW)
            Canvas_Inicio.create_text(680, 420, text=Read("4A.txt", 1), fill = "White", font = ("Consolas","15"),anchor =NW)
        except:
            pass


### ========== VENTANA CREAR ESCUDERÍAS ========== ###

def Ventana_crear_escuderias():
    # Definir la ventana, su canvas y el tamaño respectivo
    Ventana_Crear_Escuderias = Toplevel()
    Ventana_Crear_Escuderias.title("Crear Escuderías")
    Ventana_Crear_Escuderias.minsize(550, 350)
    Ventana_Crear_Escuderias.resizable(width = NO, height = NO)
    Canvas_Crear_Escuderias = Canvas(Ventana_Crear_Escuderias, width = 550, height = 350, bg = "grey")
    Canvas_Crear_Escuderias.place(x = 0, y = 0)

    Canvas_Crear_Escuderias.create_text(140, 10, text="Agregar nueva escudería", fill = "dark turquoise", font = ("Arial black","18"),anchor =NW)

    # Entrys para obtener la información proporcionada por el usuario
    global Ent1, Ent2, Ent3, v, v2, I1, I2, I3, I4, I5, I6, I7, I8
    Canvas_Crear_Escuderias.create_text(20, 70, text="Nombre", font = ("Consolas","13"),anchor =NW)
    Ent1 = Entry(Canvas_Crear_Escuderias,font=("Consolas",13), width=15 ,bg="white",fg="black")
    Ent1.place(x=110,y=70)
    
    Canvas_Crear_Escuderias.create_text(290, 70, text="Ubicación", font = ("Consolas","13"),anchor =NW)
    Ent2 = Entry(Canvas_Crear_Escuderias,font=("Consolas",13), width=15 ,bg="white",fg="black")
    Ent2.place(x=380,y=70)

    Canvas_Crear_Escuderias.create_text(20, 100, text="Número de\nescudería", font = ("Consolas","13"),anchor =NW)
    Ent3 = Entry(Canvas_Crear_Escuderias,font=("Consolas",12), width=5 ,bg="white",fg="black")
    Ent3.place(x=110,y=105)

    Canvas_Crear_Escuderias.create_text(40, 150, text="Seleccione el logo", fill = "black", font = ("Consolas","12"),anchor =NW)

    # Radiobuttons para que el usuario seleccione
    v = IntVar()
    R1 = Radiobutton(Canvas_Crear_Escuderias, text = "1", font = ("Consolas", "12"), anchor = NW, value = 1, variable = v, command = poner_logo)
    R1.place(x = 27, y= 220)
    R2 = Radiobutton(Canvas_Crear_Escuderias, text = "2", font  = ("Consolas", "12"), anchor = NW, value = 2, variable = v, command = poner_logo)
    R2.place(x = 140, y= 220)
    R3 = Radiobutton(Canvas_Crear_Escuderias, text = "3", font = ("Consolas", "12"), anchor = NW, value = 3, variable = v, command = poner_logo)
    R3.place(x = 27, y= 310)
    R4 = Radiobutton(Canvas_Crear_Escuderias, text = "4", font  = ("Consolas", "12"), anchor = NW, value = 4, variable = v, command = poner_logo)
    R4.place(x = 140, y= 310)

    # Crear imágenes
    I1 = cargarimagen("logo1.png")
    Imagen1 = Canvas_Crear_Escuderias.create_image(20,170, image = I1, anchor = NW)
    I2 = cargarimagen("logo2.png")
    Imagen2 = Canvas_Crear_Escuderias.create_image(130,170, image = I2, anchor = NW)
    I3 = cargarimagen("logo3.png")
    Imagen3 = Canvas_Crear_Escuderias.create_image(20,260, image = I3, anchor = NW)
    I4 = cargarimagen("logo4.png")
    Imagen4 = Canvas_Crear_Escuderias.create_image(130,260, image = I4, anchor = NW)
    I5 = cargarimagen("patro1.png")
    Imagen5 = Canvas_Crear_Escuderias.create_image(290,170, image = I5, anchor = NW)
    I6 = cargarimagen("patro2.png")
    Imagen6 = Canvas_Crear_Escuderias.create_image(400,170, image = I6, anchor = NW)
    I7 = cargarimagen("patro3.png")
    Imagen7 = Canvas_Crear_Escuderias.create_image(260,260, image = I7, anchor = NW)
    I8 = cargarimagen("patro4.png")
    Imagen8 = Canvas_Crear_Escuderias.create_image(370,260, image = I8, anchor = NW)
    
    Canvas_Crear_Escuderias.create_text(280, 150, text="Seleccione un patrocinador", fill = "black", font = ("Consolas","12"),anchor =NW)

    # Radiobuttons para que el usuario seleccione
    v2 = IntVar()
    R5 = Radiobutton(Canvas_Crear_Escuderias, text = "1", font = ("Consolas", "12"), anchor = NW, value = 1, variable = v2, command = poner_patro)
    R5.place(x = 300, y= 220)
    R6 = Radiobutton(Canvas_Crear_Escuderias, text = "2", font  = ("Consolas", "12"), anchor = NW, value = 2, variable = v2, command = poner_patro)
    R6.place(x = 410, y= 220)
    R7 = Radiobutton(Canvas_Crear_Escuderias, text = "3", font = ("Consolas", "12"), anchor = NW, value = 3, variable = v2, command = poner_patro)
    R7.place(x = 300, y= 310)
    R8 = Radiobutton(Canvas_Crear_Escuderias, text = "4", font  = ("Consolas", "12"), anchor = NW, value = 4, variable = v2, command = poner_patro)
    R8.place(x = 410, y= 310)

    # Botones para cambiar de ventana
    Agregar_Escuderia_Button = Button(Canvas_Crear_Escuderias, text = "Crear Escudería", bg = "black", fg = "white", command = Agregar_escuderia)
    Agregar_Escuderia_Button.place(x = 360, y = 100)
     
    def Cerrar_crear_escuderias():
        Ventana_Crear_Escuderias.destroy()
        Ventana_Escuderias.deiconify()

    Crear_Escuderias_Cerrar_Button = Button(Canvas_Crear_Escuderias, text = "Regresar a \n escuderías", bg = "black", fg = "white", command = Cerrar_crear_escuderias)
    Crear_Escuderias_Cerrar_Button.place(x = 460, y = 290)

    Ventana_Crear_Escuderias.mainloop()

"""
Funciones para colocar las imágenes de los nuevos logos y patrocinadores
de las escuderías que se crean. Evalúa los radiobutton seleccionados.
"""
def poner_logo():
    s = v.get()
    y = int(Ent3.get())*60
    if s == 1: 
        Imagen = Canvas_Escuderias.create_image(620,y, image = I1, anchor = NW)
    elif s == 2: 
        Imagen = Canvas_Escuderias.create_image(620,y, image = I2, anchor = NW)
    elif s == 3:
        Imagen = Canvas_Escuderias.create_image(620,y, image = I3, anchor = NW)
    elif s == 4:
        Imagen = Canvas_Escuderias.create_image(620,y, image = I4, anchor = NW)
def poner_patro():
    s = v2.get()
    y = int(Ent3.get())*60
    if s == 1:
        Imagen = Canvas_Escuderias.create_image(720,y, image = I5, anchor = NW)
    elif s == 2:
        Imagen = Canvas_Escuderias.create_image(720,y, image = I6, anchor = NW)
    elif s == 3: 
        Imagen = Canvas_Escuderias.create_image(720,y, image = I7, anchor = NW)
    elif s == 4:
        Imagen = Canvas_Escuderias.create_image(720,y, image = I8, anchor = NW)
        
"""
Función para crear una nueva escudería.
Toma los datos que el usuario ingresa en los entry, crea un
archivo de texto y los escribe en el mismo.
"""   
def Agregar_escuderia():
    archivo = str(Ent3.get())+"E"+ ".txt"
    yval = int(Ent3.get())*60
    archivo_write = open(archivo, "w")
    Nombre = str(Ent1.get())+ "\n"
    archivo_write.write(Nombre)
    Ubic = str(Ent2.get())+ "\n"
    archivo_write.write(Ubic)
    num = str(Ent3.get())+ "\n"
    archivo_write.write(num)
    archivo_write.close()
    Poner_Texto_Escud()

"""
Función para colocar el texto de las escuderías nuevas en la ventana de
todas las demás.
"""

def Poner_Texto_Escud():
    try:
        Canvas_Escuderias.create_text(50, 360, text=Read("6E.txt", 0), fill = "Black", font = ("Consolas","15"),anchor =NW)
        Canvas_Escuderias.create_text(400, 360, text=Read("6E.txt", 1), fill = "Black", font = ("Consolas","15"),anchor =NW)
        Canvas_Escuderias.create_text(30, 360, text=Read("6E.txt", 2), fill = "Black", font = ("Consolas","15"),anchor =NW)
    except:
        pass
    try:
        Canvas_Escuderias.create_text(50, 420, text=Read("7E.txt", 0), fill = "Black", font = ("Consolas","15"),anchor =NW)
        Canvas_Escuderias.create_text(400, 420, text=Read("7E.txt", 1), fill = "Black", font = ("Consolas","15"),anchor =NW)
        Canvas_Escuderias.create_text(30, 420, text=Read("7E.txt", 2), fill = "Black", font = ("Consolas","15"),anchor =NW)
    except:
        pass
    try:
        Canvas_Escuderias.create_text(50, 480, text=Read("8E.txt", 0), fill = "Black", font = ("Consolas","15"),anchor =NW)
        Canvas_Escuderias.create_text(400, 480, text=Read("8E.txt", 1), fill = "Black", font = ("Consolas","15"),anchor =NW)
        Canvas_Escuderias.create_text(30, 480, text=Read("8E.txt", 2), fill = "Black", font = ("Consolas","15"),anchor =NW)
    except:
        pass


### ==========   VENTANA CAMBIAR LOGO Y PATROCINADOR   ========== ###
    
def Ventana_cambiar():
    # Definir la ventana, su canvas y el tamaño respectivo
    Ventana_Cambiar = Toplevel()
    Ventana_Cambiar.title("Cambiar")
    Ventana_Cambiar.minsize(550, 550)
    Ventana_Cambiar.resizable(width = NO, height = NO)
    Canvas_Cambiar = Canvas(Ventana_Cambiar, width = 550, height = 550, bg = "white")
    Canvas_Cambiar.place(x = 0, y = 0)

    Canvas_Cambiar.create_text(100, 10, text="Nuevo logo y patrocinador", fill = "dark turquoise", font = ("Arial black","18"),anchor =NW)
    Canvas_Cambiar.create_text(40, 50, text="Seleccione el logo", fill = "black", font = ("Consolas","12"),anchor =NW)

    # Radiobuttons para que el usuario seleccione
    global var, var2, I1, I2, I3, I5, I6, I7
    var = IntVar()
    Rb1 = Radiobutton(Canvas_Cambiar, text = "1", font = ("Consolas", "12"), anchor = NW, value = 1, variable = var, command = poner_logo_nuevo)
    Rb1.place(x = 170, y= 150)
    Rb2 = Radiobutton(Canvas_Cambiar, text = "2", font  = ("Consolas", "12"), anchor = NW, value = 2, variable = var, command = poner_logo_nuevo)
    Rb2.place(x = 170, y= 300)
    Rb3 = Radiobutton(Canvas_Cambiar, text = "3", font = ("Consolas", "12"), anchor = NW, value = 3, variable = var, command = poner_logo_nuevo)
    Rb3.place(x = 170, y= 450)

    # Crear imágenes
    I1 = cargarimagen("logo_inicio2.png")
    Imagen1 = Canvas_Cambiar.create_image(20,100, image = I1, anchor = NW)
    I2 = cargarimagen("logo_inicio3.png")
    Imagen2 = Canvas_Cambiar.create_image(20,250, image = I2, anchor = NW)
    I3 = cargarimagen("Andretti-logo.png")
    Imagen3 = Canvas_Cambiar.create_image(20,400, image = I3, anchor = NW)
    I5 = cargarimagen("shell_logo.png")
    Imagen5 = Canvas_Cambiar.create_image(290,100, image = I5, anchor = NW)
    I6 = cargarimagen("roshfrans.png")
    Imagen6 = Canvas_Cambiar.create_image(290,250, image = I6, anchor = NW)
    I7 = cargarimagen("Heineken-Logo.png")
    Imagen7 = Canvas_Cambiar.create_image(290,400, image = I7, anchor = NW)
    
    Canvas_Cambiar.create_text(280, 50, text="Seleccione un patrocinador", fill = "black", font = ("Consolas","12"),anchor =NW)

    # Radiobuttons para que el usuario seleccione
    var2 = IntVar()
    Rb5 = Radiobutton(Canvas_Cambiar, text = "1", font = ("Consolas", "12"), anchor = NW, value = 1, variable = var2, command = poner_patro_nuevo)
    Rb5.place(x = 430, y= 150)
    Rb6 = Radiobutton(Canvas_Cambiar, text = "2", font  = ("Consolas", "12"), anchor = NW, value = 2, variable = var2, command = poner_patro_nuevo)
    Rb6.place(x = 430, y= 300)
    Rb7 = Radiobutton(Canvas_Cambiar, text = "3", font = ("Consolas", "12"), anchor = NW, value = 3, variable = var2, command = poner_patro_nuevo)
    Rb7.place(x = 430, y= 450)
     
    def Cerrar_cambiar():
        Ventana_Cambiar.destroy()

    Cambiar_Cerrar_Button = Button(Canvas_Cambiar, text = "Regresar", bg = "black", fg = "white", command = Cerrar_cambiar)
    Cambiar_Cerrar_Button.place(x = 470, y = 500)

    Ventana_Cambiar.mainloop()

"""
Funciones para colocar las imágenes de los nuevos logos y patrocinadores
de la escudería principal. Evalúa los radiobutton seleccionados.
"""
def poner_logo_nuevo():
    s = var.get()
    if s == 1: 
        Imagen = Canvas_Inicio.create_image(468,430, image = I1, anchor = NW)
    elif s == 2: 
        Imagen = Canvas_Inicio.create_image(468,430, image = I2, anchor = NW)
    elif s == 3:
        Imagen = Canvas_Inicio.create_image(468,430, image = I3, anchor = NW)
def poner_patro_nuevo():
    s = var2.get()
    if s == 1:
        Imagen = Canvas_Inicio.create_image(340,430, image = I5, anchor = NW)
    elif s == 2:
        Imagen = Canvas_Inicio.create_image(340,430, image = I6, anchor = NW)
    elif s == 3: 
        Imagen = Canvas_Inicio.create_image(340,430, image = I7, anchor = NW)

        
### ========== VENTANA DE PILOTO ========== ###
    
def Ventana_pilot(archivo):
    Ventana_pilot = Toplevel()
    Ventana_pilot.title("Piloto")
    Ventana_pilot.minsize(350, 350)
    Ventana_pilot.resizable(width = NO, height = NO)
    Canvas_pilot = Canvas(Ventana_pilot, width = 350, height = 350, bg = "black")
    Canvas_pilot.place(x = 0, y = 0)

    # Creación de texto desde archivos de texto
    Canvas_pilot.create_text(30, 30, text="Nombre:", fill = "White", font = ("Consolas","13"),anchor =NW)
    La_1 = Label(Ventana_pilot, text = Read(archivo, 0), font = ("Consolas","13"), bg = "black", fg = "dark turquoise", anchor = NW)
    La_1.place(x = 200, y = 30)
    Canvas_pilot.create_text(30, 70, text="Edad:", fill = "White", font = ("Consolas","13"),anchor =NW)
    La_2 = Label(Ventana_pilot, text = Read(archivo, 1), font = ("Consolas","13"), bg = "black", fg = "white", anchor = NW)
    La_2.place(x = 200, y = 70)
    Canvas_pilot.create_text(30, 100, text="Nacionalidad:", fill = "White", font = ("Consolas","13"),anchor =NW)
    La_3 = Label(Ventana_pilot, text = Read(archivo, 2), font = ("Consolas","13"), bg = "black", fg = "dark turquoise", anchor = NW)
    La_3.place(x = 200, y = 100)
    Canvas_pilot.create_text(30, 130, text="Temporada:", fill = "White", font = ("Consolas","13"),anchor =NW)
    La_4 = Label(Ventana_pilot, text = Read(archivo, 3), font = ("Consolas","13"), bg = "black", fg = "white", anchor = NW)
    La_4.place(x = 200, y = 130)
    Canvas_pilot.create_text(30, 160, text="Competencias:", fill = "White", font = ("Consolas","13"),anchor =NW)
    La_5 = Label(Ventana_pilot, text = Read(archivo, 4), font = ("Consolas","13"), bg = "black", fg = "white", anchor = NW)
    La_5.place(x = 200, y = 160)
    Canvas_pilot.create_text(30, 190, text="Podios:", fill = "White", font = ("Consolas","13"),anchor =NW)
    La_6 = Label(Ventana_pilot, text = Read(archivo, 5), font = ("Consolas","13"), bg = "black", fg = "white", anchor = NW)
    La_6.place(x = 200, y = 190)
    Canvas_pilot.create_text(30, 220, text="Victorias:", fill = "White", font = ("Consolas","13"),anchor =NW)
    La_7 = Label(Ventana_pilot, text = Read(archivo, 6), font = ("Consolas","13"), bg = "black", fg = "white", anchor = NW)
    La_7.place(x = 200, y = 220)
    Canvas_pilot.create_text(30, 250, text="Abandonos:", fill = "White", font = ("Consolas","13"),anchor =NW)
    La_8 = Label(Ventana_pilot, text = Read(archivo, 7), font = ("Consolas","13"), bg = "black", fg = "white", anchor = NW)
    La_8.place(x = 200, y = 250)
    Canvas_pilot.create_text(30, 280, text="Escudería:", fill = "White", font = ("Consolas","13"),anchor =NW)
    La_9 = Label(Ventana_pilot, text = Read(archivo, 9), font = ("Consolas","13"), bg = "black", fg = "dark turquoise", anchor = NW)
    La_9.place(x = 200, y = 280)
    
    Ventana_pilot.mainloop()   



### ==========  VENTANA TEST DRIVE  ================ ###
        
def  Ventana_test_drive():
                        
    global Canvas_Test, bateria1, bateria2, bateria3, Imagen_Luna, Imagen_Sol#Convierte en globales las imagenes utilizadas para la beteria y para la luz del sensor
    Ventana_Inicio.withdraw()
    Ventana_Test = Toplevel()
    Ventana_Test.title("TEST DRIVE")
    Ventana_Test.minsize(1280,720)
    Ventana_Test.resizable(width = NO, height = NO)
    Canvas_Test = Canvas(Ventana_Test, width = 1280, height = 720)
    Canvas_Test.place(x=0,y=0)
    #Se cargan imagenes y botones necesarios
    Imag_Fondo_Test = cargarimagen("carretera.png") 
    Fondo_Test = Canvas_Test.create_image(0,0, image = Imag_Fondo_Test, anchor = NW)
    ImagenCarro_Test = cargarimagen("carrotest.png")
    ImagCarro_Test = Canvas_Test.create_image(0,200,image = ImagenCarro_Test, anchor = NW)
    MovimientoEspecialBoton = Button(Canvas_Test, text = "Movimiento Especial", bg = "dark turquoise", fg = "black",borderwidth = 5, command = mov_esp)
    MovimientoEspecialBoton.place(x = 1070, y = 200)
    CelebracionBoton = Button(Canvas_Test, text = "Movimiento Celebración", bg = "dark turquoise", fg = "black",borderwidth = 5, command = celebracion)
    CelebracionBoton.place(x = 1070, y = 240)
    ImagenArriba = cargarimagen("arriba.png")
    ImagenDerecha = cargarimagen("derecha.png")
    ImagenIzquierda = cargarimagen("izquierda.png")
    ImagenReversa = cargarimagen("reversa.png")
    ImagenStop = cargarimagen("stop.png")
    Imagen_Sol = cargarimagen("sol.png")
    Imagen_Luna = cargarimagen("luna.png")
#Cierra la ventana de test drive y vuelve a la ventana de inicio
    def Cerrar_Test():
        Ventana_Test.destroy()
        Ventana_Inicio.deiconify()
        Ventana_Toplevel = False
        
    #Se definen mas botones e imagenes
    ArribaBoton = Button(Canvas_Test, image = ImagenArriba, bg = "dark turquoise", fg = "black",borderwidth = 5, command = send_pwm)
    ArribaBoton.place(x = 150, y = 400)
    DerechaBoton = Button(Canvas_Test, image = ImagenDerecha, bg = "dark turquoise", fg = "black",borderwidth = 5, command = send_dere)
    DerechaBoton.place(x = 250, y = 500)
    IzquierdaBoton = Button(Canvas_Test, image = ImagenIzquierda, bg = "dark turquoise", fg = "black",borderwidth = 5, command = send_izq)
    IzquierdaBoton.place(x = 50, y = 500)
    StopBoton = Button(Canvas_Test, image = ImagenStop, bg = "dark turquoise", fg = "black", borderwidth = 5, command = send_frenar)
    StopBoton.place(x=150, y = 500)
    RevBoton = Button(Canvas_Test, image = ImagenReversa, bg = "dark turquoise", fg = "black", borderwidth = 5, command = send_reversa)
    RevBoton.place(x=150, y=600)
    ApagaBoton = Button(Canvas_Test, text = "Apagar todas las luces", bg = "dark turquoise", fg = "black", borderwidth = 5, command = apagar_luces)
    ApagaBoton.place(x=1100, y = 500)
    BateriaBoton = Button(Canvas_Test, text = "Valor Batería", bg = "dark turquoise", fg = "black", borderwidth = 5, command = mostrar_bateria)
    BateriaBoton.place(x=1070, y = 280)
    SensorBoton = Button(Canvas_Test, text = "Valor Sensor",bg="dark turquoise", fg="black",borderwidth=5,command=mostrar_luz)
    SensorBoton.place(x = 1070,y= 380)

    bateria1 = cargarimagen("bateriallena.png")
    bateria2 = cargarimagen("bateriamedias.png")
    bateria3 = cargarimagen("bateriabaja.png")

    Test_Cerrar_Button = Button(Canvas_Test, text = "Regresar al menú", bg = "dark turquoise", fg = "black", command = Cerrar_Test)
    Test_Cerrar_Button.place(x = 1100, y = 600)       


                    
    Ventana_Test.mainloop()

  
#Esta funcion recibe el return del "sense;" y revisa los primeros valores antes de los dos puntos y los mete en una lista
#Esta lista la evalua en enteros() para convertirla a un int
def revisar_bateria():
    print(carro.send("sense;"))
    bate = []
    valores = carro.send("sense;")
    cont = 0
    for i in range(len(valores)):
        if  valores[i] != ":" and cont == 0:
            bate.append(valores[i])
        elif valores[i] == ":":
            break
    return enteros(bate)
#Esta funcion recibe el return del "sense;" y revisa los valores posteriores a los dos puntos y los guarda en una lista
#Esta lista la evalua en enteros() para convertirla a un int
def revisar_sensor():
    luz = []
    valores = carro.send("sense;")
    cont = 0
    for i in range(len(valores)):
        if valores[i] == ":":
            cont += 1
        elif valores[i] != ":" and cont != 0:
            luz.append(valores[i])
    return enteros(luz)
#Esta funcion recibe el resultado de revisar_sensor() y revisa si es 0 o si es uno para poner ya sea una luna o un sol
def mostrar_luz():
    print(revisar_sensor())
    if revisar_sensor() == 1:
        Imag_Sol = Canvas_Test.create_image(200,0,image = Imagen_Sol, anchor = NW)
    else:
        Imag_Luna = Canvas_Test.create_image(200,0,image = Imagen_Luna, anchor = NW)
        
#Esta funcion recibe el resultado de revisar_bateria() para compararlo y dependiendo del valor pone una imagen de bateria dependiendo del estado    
def mostrar_bateria():
    print(revisar_bateria())
    if revisar_bateria() <= 50:
        Bateria_llena = Canvas_Test.create_image(0,0,image = bateria1, anchor = NW)
    elif 50 < revisar_bateria() < 100:
        
        Bateria_medias = Canvas_Test.create_image(0,0,image = bateria2, anchor = NW)
    else:
        Bateria_baja = Canvas_Test.create_image(0,0,image = bateria3, anchor = NW)
        
        

#E:Recibe una lista proveniente de revisar_bateria() o revisar_sensor() , S: las convierte a entero, r:---
#Las convierte a entero para luego poder hacer comparaciones numericas        
def enteros(lista):
    result = 0
    j = 1
    for i in range(len(lista)):
        result += int(lista[i]) * 10 ** (len(lista)-j)
        j += 1
    return result
        
           
#Hace un movimiento mediante comandos y time sleeps, se supone ue hace una "V"    
def mov_esp():
    carro.send("lf:0;")
    carro.send("lb:0;")
    carro.send("ll:0;")
    carro.send("lr:0;")
    carro.send("dir:-1;")
    time.sleep(1)
    carro.send("pwm:-1000;")
    time.sleep(1)
    carro.send("pwm:0;")
    time.sleep(1)
    carro.send("pwm:1000;")
    time.sleep(1)
    carro.send("dir:1;")
    time.sleep(1)
    carro.send("pwm:-1000;")
#Hace una celebracion con las luces prendiendolas y pagandolas como si fuera un circulo.
def celebracion ():
    carro.send("lf:1;")
    time.sleep(0.2)
    carro.send("lf:0;")
    time.sleep(0.2)
    carro.send("ll:1;")
    time.sleep(0.2)
    carro.send("ll:0;")
    time.sleep(0.2)
    carro.send("lb:1;")
    time.sleep(0.2)
    carro.send("lb:0;")
    time.sleep(0.2)
    carro.send("lr:1;")
    time.sleep(0.2)
    carro.send("lr:0;")
    time.sleep(0.2)
    carro.send("lf:1;")
    time.sleep(0.2)
    carro.send("lf:0;")
    time.sleep(0.2)
    carro.send("ll:1;")
    time.sleep(0.2)
    carro.send("ll:0;")
    time.sleep(0.2)
    carro.send("lb:1;")
    time.sleep(0.2)
    carro.send("lb:0;")
    time.sleep(0.2)
    carro.send("lr:1;")
    time.sleep(0.2)
    carro.send("lr:0;")
    time.sleep(0.2)
    carro.send("lf:1;")
    time.sleep(0.2)
    carro.send("lf:0;")
    time.sleep(0.2)
    carro.send("ll:1;")
    time.sleep(0.2)
    carro.send("ll:0;")
    time.sleep(0.2)
    carro.send("lb:1;")
    time.sleep(0.2)
    carro.send("lb:0;")
    time.sleep(0.2)
    carro.send("lr:1;")
    time.sleep(0.2)
    carro.send("lr:0;")
    time.sleep(0.2)
    carro.send("lf:1;")
    time.sleep(0.2)
    carro.send("lf:0;")
    time.sleep(0.2)
    carro.send("ll:1;")
    time.sleep(0.2)
    carro.send("ll:0;")
    time.sleep(0.2)
    carro.send("lb:1;")
    time.sleep(0.2)
    carro.send("lb:0;")
    time.sleep(0.2)
    carro.send("lr:1;")
    time.sleep(0.2)
    carro.send("lr:0;")
    time.sleep(0.2)
    carro.send("lf:1;")
    time.sleep(0.2)
    carro.send("lf:0;")
    time.sleep(0.2)
    carro.send("ll:1;")
    time.sleep(0.2)
    carro.send("ll:0;")
    time.sleep(0.2)
    carro.send("lb:1;")
    time.sleep(0.2)
    carro.send("lb:0;")
    time.sleep(0.2)
    carro.send("lr:1;")
    time.sleep(0.2)
    carro.send("lr:0;")
    time.sleep(0.2)
    carro.send("lf:1;")
    time.sleep(0.2)
    carro.send("lf:0;")
    time.sleep(0.2)
    carro.send("ll:1;")
    time.sleep(0.2)
    carro.send("ll:0;")
    time.sleep(0.2)
    carro.send("lb:1;")
    time.sleep(0.2)
    carro.send("lb:0;")
    time.sleep(0.2)
    carro.send("lr:1;")
    time.sleep(0.2)
    carro.send("lr:0;")
    
#Apaga todas las luces del carro, meramente auxiliar     
def apagar_luces ():
    carro.send("lf:0;")
    carro.send("lb:0;")
    carro.send("ll:0;")
    carro.send("lr:0;")
#Apaga las luces, enderece la direccion y avanza.  
def send_pwm ():
    carro.send("lb:0;")
    carro.send("ll:0;")
    carro.send("lr:0;")
    carro.send("pwm:-700;")
    carro.send("dir:0;")
    print("Avanza")
#Hace la animacion de prender y apagar la direccionales y luego gira a la izquierda y avanza
def send_izq ():
    carro.send("lr:0;")
    carro.send("lb:0;")
    carro.send("ll:1;")
    time.sleep(0.2)
    carro.send("ll:0;")
    time.sleep(0.2)
    carro.send("ll:1;")
    time.sleep(0.2)
    carro.send("ll:0;")
    time.sleep(0.2)
    carro.send("ll:1;")
    time.sleep(0.2)
    carro.send("ll:0;")
    time.sleep(0.2)
    carro.send("ll:1;")
    time.sleep(0.2)
    carro.send("ll:0;")
    time.sleep(0.2)
    carro.send("ll:1;")
    time.sleep(0.2)
    carro.send("pwm:-700;")
    carro.send("dir:-1;")
    time.sleep(0.2)
    carro.send("lb:0;")
    carro.send("lr:0;")
    carro.send("ll:0;")
    print("Izquierda")
#Hace animacion de luz direccional derecha intermitente y luego gira a la derecha y avanza.
def send_dere ():
    carro.send("ll:0;")
    carro.send("lb:0;")
    carro.send("lr:1;")
    time.sleep(0.2)
    carro.send("lr:0;")
    time.sleep(0.2)
    carro.send("lr:1;")
    time.sleep(0.2)
    carro.send("lr:0;")
    time.sleep(0.2)
    carro.send("lr:1;")
    time.sleep(0.2)
    carro.send("lr:0;")
    time.sleep(0.2)
    carro.send("lr:1;")
    time.sleep(0.2)
    carro.send("lr:0;")
    time.sleep(0.2)
    carro.send("lr:1;")
    time.sleep(0.2)
    carro.send("pwm:-700;")
    carro.send("dir:1;")
    time.sleep(0.2)
    carro.send("lb:0;")
    carro.send("lr:0;")
    carro.send("ll:0;")
    print("Derecha")
#Apaga ambos motores y prende las luces de freno (rojas)
def send_frenar():
    carro.send("lb:1;")
    carro.send("ll:0;")
    carro.send("lr:0;")
    carro.send("pwm:0;")
    carro.send("dir:0;")
    print("Frenó")
#Va para atras y prende las luces traseras mientras lo hace.
def send_reversa():
    carro.send("pwm:1000;")
    carro.send("dir:0")
    time.sleep(0.1)
    carro.send("lb:1;")
    carro.send("ll:0;")
    carro.send("lr:0;")
    print("Reversa")



# Inicializar la pantalla de inicio
Ventana_inicio()
    
